/**
 * PressArk Chat Panel Frontend Logic
 */
(function () {
	'use strict';

	var wpI18n = window.wp && window.wp.i18n ? window.wp.i18n : {};
	var __ = wpI18n.__ || function (text) { return text; };
	var _n = wpI18n._n || function (single, plural, number) {
		return Number(number) === 1 ? single : plural;
	};
	var sprintf = wpI18n.sprintf || function (format) {
		var args = Array.prototype.slice.call(arguments, 1);
		var index = 0;
		return String(format).replace(/%(?:(\d+)\$)?[sd]/g, function (match, position) {
			var argIndex = position ? parseInt(position, 10) - 1 : index;
			var replacement = typeof args[argIndex] !== 'undefined' ? args[argIndex] : '';
			if (!position) {
				index++;
			}
			return String(replacement);
		});
	};

	/* ── Inline SVG Icon Helper ─────────────────────────────────────── */
	var pwIcons = {
		zap:       '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 1.5L3 9h4.5l-.5 5.5L13 7H8.5l.5-5.5z"/></svg>',
		moon:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13.5 8.5a5.5 5.5 0 1 1-6-6 4.5 4.5 0 0 0 6 6z"/></svg>',
		sun:       '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="3"/><path d="M8 1.5v1.25M8 13.25v1.25M1.5 8h1.25M13.25 8h1.25M3.4 3.4l.9.9M11.7 11.7l.9.9M12.6 3.4l-.9.9M4.3 11.7l-.9.9"/></svg>',
		arrowRight:'<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8h10"/><path d="M9 4l4 4-4 4"/></svg>',
		pen:       '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11.2 2.3a1.6 1.6 0 0 1 2.5 2l-8 8L2.5 13l.7-3.2z"/></svg>',
		search:    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="7" cy="7" r="4.5"/><path d="m13.5 13.5-3-3"/></svg>',
		shield:    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1.5L2.5 4v3.5c0 3.5 2.3 6 5.5 7 3.2-1 5.5-3.5 5.5-7V4z"/></svg>',
		barChart:  '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 13.5V7M10 13.5V2.5M2.5 13.5v-3M13.5 13.5V5"/></svg>',
		sparkles:  '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1.5l1 3.5 3.5 1-3.5 1-1 3.5-1-3.5L3.5 6l3.5-1z"/><path d="M12 10l.5 1.5 1.5.5-1.5.5-.5 1.5-.5-1.5L10 12l1.5-.5z"/></svg>',
		refresh:   '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 2.5v4h4"/><path d="M2.5 10a5.5 5.5 0 1 0 1-5.5L1.5 6.5"/></svg>',
		broom:     '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 9l6.5-6.5M4 10l-1.5 4.5L7 13l1-1"/><path d="M7 13c1.5 0 4-1.5 6.5-4"/></svg>',
		clipboard: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="2.5" width="9" height="11" rx="1.5"/><path d="M6 2.5V1.5h4v1"/><path d="M6 7h4M6 9.5h2.5"/></svg>',
		store:     '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 5.5l1-3.5h10l1 3.5"/><path d="M2 5.5c0 1.1.9 2 2 2s2-.9 2-2c0 1.1.9 2 2 2s2-.9 2-2c0 1.1.9 2 2 2s2-.9 2-2"/><path d="M2.5 7.5v6h11v-6"/><path d="M6.5 13.5v-3.5h3v3.5"/></svg>',
		trendUp:   '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 3.5l-5 5-3-3-5 5"/><path d="M10 3.5h4.5V7"/></svg>',
		check:     '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 8.5l3 3 6-6"/></svg>',
		x:         '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
		warning:   '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.13 2.5L1.5 12.5h13L8.87 2.5a1 1 0 0 0-1.74 0z"/><path d="M8 6.5v2.5"/><circle cx="8" cy="11" r=".5" fill="currentColor" stroke="none"/></svg>',
		info:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6.5"/><path d="M8 7v4"/><circle cx="8" cy="5" r=".5" fill="currentColor" stroke="none"/></svg>',
		fileDown:  '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 1.5H4.5a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V4.5z"/><path d="M8 7v4M6 9.5L8 11.5 10 9.5"/></svg>',
		loader:    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1.5v2M8 12.5v2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M1.5 8h2M12.5 8h2M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4"/></svg>',
		dot:       '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="3"/></svg>',
		pencil:    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.5l3 3L5 14H2v-3z"/></svg>',
		undo:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h6a3 3 0 1 1 0 6H8"/><path d="M6.5 3.5L4 6l2.5 2.5"/></svg>',
		lock:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="7" width="9" height="6.5" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>',
		mail:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1.5" y="3.5" width="13" height="9" rx="1.5"/><path d="M1.5 5l6.5 4 6.5-4"/></svg>',
		send:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 1.5l-6 13-2.5-5.5L1.5 6.5z"/><path d="M14.5 1.5L6 9"/></svg>',
		house:     '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 6.5L8 2l5.5 4.5V13a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z"/><path d="M6 14V9h4v5"/></svg>',
		checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6.5"/><path d="M5.5 8l2 2 3.5-3.5"/></svg>',
		xCircle:   '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6.5"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5"/></svg>',
		dollar:    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1.5v13"/><path d="M11 4.5H6.5a2 2 0 0 0 0 4h3a2 2 0 0 1 0 4H5"/></svg>',
		package:   '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 4.5L8 1.5l6 3v7l-6 3-6-3z"/><path d="M2 4.5L8 8l6-3.5"/><path d="M8 8v6.5"/></svg>',
		alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6.5"/><path d="M8 5v3.5"/><circle cx="8" cy="11" r=".5" fill="currentColor" stroke="none"/></svg>',
		star:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1.5l1.9 4 4.4.6-3.2 3 .8 4.4L8 11.3 4.1 13.5l.8-4.4-3.2-3 4.4-.6z"/></svg>',
		gift:      '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1.5" y="6" width="13" height="3" rx="1"/><rect x="2.5" y="9" width="11" height="5" rx="1"/><path d="M8 6v8"/><path d="M8 6C6.5 6 4 4.5 4 3a2 2 0 0 1 4 0"/><path d="M8 6c1.5 0 4-1.5 4-3a2 2 0 0 0-4 0"/></svg>',
		statusDot: '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="currentColor"/></svg>'
	};

	/** Wrap an icon SVG string in a .pw-icon span for inline use. */
	function pwIcon(name, tone) {
		var toneClass = tone ? ' pw-icon--' + tone : '';
		return '<span class="pw-icon' + toneClass + '">' + (pwIcons[name] || '') + '</span>';
	}

	var PANEL_STATE_KEY = 'pressark_panel_open';
	var THEME_STATE_KEY = 'pressark_panel_theme';

	var PressArk = {
		panel: null,
		messagesEl: null,
		inputEl: null,
		sendBtn: null,
		toggleBtn: null,
		themeBtn: null,
		themeIconEl: null,
		quotaBarEl: null,
		historySidebar: null,
		conversation: [],
		loadedGroups: [],
		checkpoint: null,
		isOpen: false,
		isSending: false,
		deepModeActive: false,
		lastMessageTime: 0,
		lastUserMessage: '',
		currentChatId: null,
		autoSaveTimer: null,
		scrollObserver: null,
		pendingActions: {},
		pendingPreviews: {},
		pendingRunIds: {},
		pendingActionIndices: {},
		actionIdCounter: 0,
		pendingResults: [],
		pendingTaskCount: 0,
		unreadTaskCount: 0,
		activityUrl: '',
		pollTimer: null,
		pollRequestInFlight: false,
		_activeRequest: null,
		_activeRunId: null,
		_confirmStreamActive: false,
		_toolProgressState: {},
		activePreviewFooterEl: null,
		planTrackerEl: null,
		planTrackerHeadEl: null,
		planTrackerBodyEl: null,
		planSummaryEl: null,
		planProgressEl: null,
		planDotsEl: null,
		planStepsEl: null,
		planRestoreEl: null,
		planRestoreProgressEl: null,
		planRestoreSummaryEl: null,
		planTrackerState: {
			collapsed: false,
			hidden: false,
			runId: '',
			steps: [],
			summary: ''
		},

		init: function () {
			this.panel = document.getElementById('pressark-panel');
			this.messagesEl = document.getElementById('pressark-messages');
			this.inputEl = document.getElementById('pressark-input');
			this.sendBtn = document.getElementById('pressark-send');
			this.toggleBtn = document.getElementById('pressark-toggle');
			this.themeBtn = document.getElementById('pressark-theme-btn');
			this.themeIconEl = this.themeBtn ? this.themeBtn.querySelector('.pressark-theme-icon') : null;
			this.quotaBarEl = document.getElementById('pressark-quota-bar');
			this.historySidebar = document.getElementById('pressark-history-panel');
			this.activityBtn = document.getElementById('pressark-activity-btn');
			this.activityCountEl = document.getElementById('pressark-activity-count');
			this.planTrackerEl = document.getElementById('pressark-plan-tracker');
			this.planTrackerHeadEl = document.getElementById('pressark-plan-head');
			this.planTrackerBodyEl = document.getElementById('pressark-plan-body');
			this.planSummaryEl = document.getElementById('pressark-plan-summary');
			this.planProgressEl = document.getElementById('pressark-plan-progress');
			this.planDotsEl = document.getElementById('pressark-plan-dots');
			this.planStepsEl = document.getElementById('pressark-plan-steps');
			this.planRestoreEl = document.getElementById('pressark-plan-restore');
			this.planRestoreProgressEl = document.getElementById('pressark-plan-restore-progress');
			this.planRestoreSummaryEl = document.getElementById('pressark-plan-restore-summary');

			if (!this.panel || !this.toggleBtn) {
				return;
			}

			var data = window.pressarkData || {};
			this.unreadTaskCount = parseInt(data.initial_unread_count || 0, 10);
			if (isNaN(this.unreadTaskCount)) {
				this.unreadTaskCount = 0;
			}
			this.activityUrl = data.activity_url || '';
			this.pendingActionIndices = {};

			// Mark frontend pages so CSS can adjust layout when panel is open.
			if (data.isFrontend) {
				document.body.classList.add('pressark-frontend');
			}

			this.loadBrandImages();
			this.restoreTheme();
			this.bindEvents();
			this.setupScrollObserver();
			this.restorePanelState();
			this.restoreConversation();
			this.updateActivityUi();
			this.syncTaskPolling(this.isOpen);
			this.renderQuotaBar();
			this.checkAutoMessage();
		},

		// ── Brand Image Loading ──────────────────────────────────────

		loadBrandImages: function () {
			var images = (window.pressarkData && window.pressarkData.images) || {};

			// Header logo (small, for the panel header on white bg)
			var headerLogo = document.getElementById('pressark-header-logo');
			if (headerLogo) {
				var logoSrc = this.findImage(images, ['PNG-LOGO', 'WHITE-APP-LOGO', 'icon-dark', 'favicon', 'icon', 'logo-icon', 'app-icon']);
				if (logoSrc) {
					headerLogo.src = logoSrc;
				} else {
					headerLogo.style.display = 'none';
				}
			}

		},

		findImage: function (images, preferredNames) {
			var i, name, key;
			for (i = 0; i < preferredNames.length; i++) {
				name = preferredNames[i];
				// Exact match
				if (images[name]) return images[name];
				// Partial match
				for (key in images) {
					if (images.hasOwnProperty(key) && key.toLowerCase().indexOf(name.toLowerCase()) !== -1) {
						return images[key];
					}
				}
			}
			// Return first available image as last resort
			var keys = Object.keys(images);
			return keys.length > 0 ? images[keys[0]] : null;
		},

		restoreTheme: function () {
			var stored = '';
			try {
				stored = window.localStorage ? window.localStorage.getItem(THEME_STATE_KEY) : '';
			} catch (e) {
				stored = '';
			}

			var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
			this.setTheme(stored || (prefersDark ? 'dark' : 'light'), false);
		},

		toggleTheme: function () {
			var currentTheme = this.panel && this.panel.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
			this.setTheme(currentTheme === 'dark' ? 'light' : 'dark', true);
		},

		setTheme: function (theme, persist) {
			var normalized = theme === 'dark' ? 'dark' : 'light';
			var nextLabel = normalized === 'dark' ? __( 'Use light mode', 'pressark' ) : __( 'Use dark mode', 'pressark' );
			var isDark = normalized === 'dark';

			if (this.panel) {
				this.panel.setAttribute('data-theme', normalized);
			}
			if (this.themeBtn) {
				this.themeBtn.classList.toggle('pressark-theme-active', isDark);
				this.themeBtn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
				this.themeBtn.setAttribute('aria-label', nextLabel);
				this.themeBtn.setAttribute('title', nextLabel);
			}
			if (this.themeIconEl) {
				this.themeIconEl.innerHTML = isDark ? pwIcons.sun : pwIcons.moon;
			}
			if (persist) {
				try {
					if (window.localStorage) {
						window.localStorage.setItem(THEME_STATE_KEY, normalized);
					}
				} catch (e) {}
			}
		},

		// ── Event Binding ────────────────────────────────────────────

		bindEvents: function () {
			var self = this;

			this.toggleBtn.addEventListener('click', function () {
				self.toggle();
			});

			var closeBtn = document.getElementById('pressark-close-btn');
			if (closeBtn) {
				closeBtn.addEventListener('click', function () {
					self.close();
				});
			}

			// Deep Mode toggle button.
			var deepModeBtn = document.getElementById('pressark-deep-mode-btn');
			if (deepModeBtn) {
				deepModeBtn.addEventListener('click', function () {
					self.toggleDeepMode();
				});
			}

			if (this.themeBtn) {
				this.themeBtn.addEventListener('click', function () {
					self.toggleTheme();
				});
			}

			// New Chat button.
			var newChatBtn = document.getElementById('pressark-new-chat-btn');
			if (newChatBtn) {
				newChatBtn.addEventListener('click', function () {
					self.newChat();
				});
			}

			if (this.activityBtn) {
				this.activityBtn.addEventListener('click', function () {
					if (self.activityUrl) {
						window.location.href = self.activityUrl;
					}
				});
			}

			// History toggle button.
			var historyBtn = document.getElementById('pressark-history-btn');
			if (historyBtn) {
				historyBtn.addEventListener('click', function () {
					self.toggleHistory();
				});
			}

			// History close button.
			var historyCloseBtn = document.getElementById('pressark-history-close');
			if (historyCloseBtn) {
				historyCloseBtn.addEventListener('click', function () {
					if (self.historySidebar) {
						self.historySidebar.style.display = 'none';
					}
				});
			}

			if (this.planTrackerHeadEl) {
				this.planTrackerHeadEl.addEventListener('click', function (e) {
					if (e.target && e.target.closest && e.target.closest('#pressark-plan-hide')) {
						return;
					}
					self.togglePlanTrackerCollapse();
				});
				this.planTrackerHeadEl.addEventListener('keydown', function (e) {
					if (e.key === 'Enter' || e.key === ' ') {
						e.preventDefault();
						self.togglePlanTrackerCollapse();
					}
				});
			}

			var planCollapseBtn = document.getElementById('pressark-plan-collapse');
			if (planCollapseBtn) {
				planCollapseBtn.addEventListener('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					self.togglePlanTrackerCollapse();
				});
			}

			var planHideBtn = document.getElementById('pressark-plan-hide');
			if (planHideBtn) {
				planHideBtn.addEventListener('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					self.hidePlanTracker();
				});
			}

			var planRestoreBtn = document.getElementById('pressark-plan-restore-btn');
			if (planRestoreBtn) {
				planRestoreBtn.addEventListener('click', function (e) {
					e.preventDefault();
					self.showPlanTracker();
				});
			}

			this.sendBtn.addEventListener('click', function () {
				var stopVisible = self.sendBtn && self.sendBtn.classList.contains('pressark-send-btn--stop');
				if (self.isSending || self._activeRequest || stopVisible) {
					self.abortActiveRequest();
				} else {
					self.sendMessage();
				}
			});

			this.inputEl.addEventListener('keydown', function (e) {
				if (e.key === 'Enter' && !e.shiftKey) {
					e.preventDefault();
					self.sendMessage();
				}
			});

			this.inputEl.addEventListener('input', function () {
				self.autoGrow();
			});

			// Keyboard shortcut: Ctrl+Shift+P / Cmd+Shift+P.
			document.addEventListener('keydown', function (e) {
				if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'P') {
					e.preventDefault();
					self.toggle();
				}
			});

			// Escape key closes the panel.
			this.panel.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') {
					e.preventDefault();
					e.stopPropagation();
					self.close();
					return;
				}

				// Focus trap: cycle Tab through interactive elements within the panel.
				if (e.key === 'Tab') {
					var focusable = self.panel.querySelectorAll(
						'button:not([disabled]):not([hidden]), textarea:not([disabled]), input:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
					);
					if (focusable.length === 0) return;

					var first = focusable[0];
					var last = focusable[focusable.length - 1];

					if (e.shiftKey) {
						if (document.activeElement === first) {
							e.preventDefault();
							last.focus();
						}
					} else {
						if (document.activeElement === last) {
							e.preventDefault();
							first.focus();
						}
					}
				}
			});
		},

		// ── Deep Mode Toggle ──────────────────────────────────────────

		toggleDeepMode: function () {
			var data = window.pressarkData;

			// Remove any existing deep mode banners to prevent stacking
			var existingIndicators = this.messagesEl.querySelectorAll('.pressark-deep-indicator');
			for (var i = 0; i < existingIndicators.length; i++) {
				existingIndicators[i].remove();
			}

			this.deepModeActive = !this.deepModeActive;
			var btn = document.getElementById('pressark-deep-mode-btn');
			if (btn) {
				btn.classList.toggle('pressark-deep-active', this.deepModeActive);
			}

			var indicator = document.createElement('div');
			indicator.className = 'pressark-message pressark-message-system pressark-deep-indicator';
			indicator.innerHTML =
				'<div class="pressark-message-content">' +
				(this.deepModeActive
					? pwIcon('zap') + ' <strong>' + this.escapeHtml(__( 'Deep Mode ON', 'pressark' )) + '</strong> - ' + this.escapeHtml(__( 'Using premium AI with extended context. Best for complex tasks.', 'pressark' ))
					: pwIcon('moon') + ' <strong>' + this.escapeHtml(__( 'Deep Mode OFF', 'pressark' )) + '</strong> - ' + this.escapeHtml(__( 'Back to standard mode.', 'pressark' ))) +
				'</div>';
			this.messagesEl.appendChild(indicator);
			this.scrollToBottom();
		},

		// ── MutationObserver for auto-scroll ──────────────────────────

		setupScrollObserver: function () {
			if (!this.messagesEl || typeof MutationObserver === 'undefined') return;

			var self = this;
			this.scrollObserver = new MutationObserver(function () {
				// Only auto-scroll if user is near the bottom (within 80px).
				var el = self.messagesEl;
				var isNearBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 80;
				if (isNearBottom) {
					self.scrollToBottom();
				}
			});

			this.scrollObserver.observe(this.messagesEl, {
				childList: true,
				subtree: true,
				characterData: true
			});
		},

		toggle: function () {
			if (this.isOpen) {
				this.close();
			} else {
				this.open();
			}
		},

		open: function () {
			this.panel.classList.add('pressark-panel-open');
			this.isOpen = true;
			sessionStorage.setItem(PANEL_STATE_KEY, 'open');
			this.setToggleVisible(false);
			this.inputEl.focus();
			this.syncTaskPolling(true);
			this.updateActivityUi();

			// Deliver any pending background task results.
			if (this.pendingResults && this.pendingResults.length > 0) {
				var remainingResults = [];
				for (var pr = 0; pr < this.pendingResults.length; pr++) {
					var pendingResult = this.pendingResults[pr] || {};
					var pendingChatId = parseInt(pendingResult.chat_id || 0, 10);
					var activeChatId = parseInt(this.currentChatId || 0, 10);
					var canRenderPending = pendingChatId < 1 || activeChatId < 1 || activeChatId === pendingChatId;

					if (pendingChatId > 0 && activeChatId < 1) {
						this.currentChatId = pendingChatId;
					}

					if (canRenderPending) {
						this.renderTaskResult(pendingResult);
					} else {
						remainingResults.push(pendingResult);
					}
				}
				this.pendingResults = remainingResults;
			}

			// Show welcome/onboarding only if no history exists.
			if (this.messagesEl.querySelectorAll('.pressark-message, .pressark-welcome').length === 0) {
				this.showWelcome();
			}
		},

		close: function () {
			this.panel.classList.remove('pressark-panel-open');
			this.isOpen = false;
			sessionStorage.setItem(PANEL_STATE_KEY, 'closed');
			this.setToggleVisible(true);

			// Return focus to the toggle button.
			if (this.toggleBtn) {
				this.toggleBtn.focus();
			}

			// Close history panel if open.
			if (this.historySidebar) {
				this.historySidebar.style.display = 'none';
			}
			this.syncTaskPolling(false);
		},

		shouldPollTasks: function () {
			return this.isOpen || this.pendingTaskCount > 0;
		},

		getTaskPollInterval: function () {
			return this.pendingTaskCount > 0 ? 15000 : 60000;
		},

		syncTaskPolling: function (immediate) {
			if (!this.shouldPollTasks()) {
				this.stopTaskPolling();
				return;
			}

			this.startTaskPolling(immediate === true);
		},

		startTaskPolling: function (immediate) {
			if (this.pollTimer) {
				clearTimeout(this.pollTimer);
				this.pollTimer = null;
			}

			var self = this;
			var delay = immediate ? 0 : this.getTaskPollInterval();
			this.pollTimer = window.setTimeout(function () {
				self.pollForTaskUpdates();
			}, delay);
		},

		stopTaskPolling: function () {
			if (this.pollTimer) {
				clearTimeout(this.pollTimer);
				this.pollTimer = null;
			}
		},

		pollForTaskUpdates: function () {
			var self = this;
			var data = window.pressarkData || {};

			if (!this.shouldPollTasks()) {
				this.stopTaskPolling();
				return;
			}

			if (this.pollRequestInFlight) {
				this.startTaskPolling(false);
				return;
			}

			this.pollRequestInFlight = true;
			this.pollTimer = null;

			fetch(data.restUrl + 'poll', {
				method: 'POST',
				cache: 'no-store',
				headers: {
					'X-WP-Nonce': data.nonce
				}
			})
				.then(function (response) {
					if (!response.ok) {
						throw new Error('Poll failed (' + response.status + ')');
					}
					return response.json();
				})
				.then(function (payload) {
					self.handleTaskPollResponse(payload || {});
				})
				.catch(function () {
					// Keep polling conservative and silent; chat send path owns user-facing errors.
				})
				.finally(function () {
					self.pollRequestInFlight = false;
					self.syncTaskPolling(false);
				});
		},

		handleTaskPollResponse: function (pw) {
			var pendingCount = parseInt(pw.pending_task_count || 0, 10);
			this.pendingTaskCount = isNaN(pendingCount) ? 0 : Math.max(0, pendingCount);
			var unreadCount = parseInt(pw.unread_count || 0, 10);
			this.unreadTaskCount = isNaN(unreadCount) ? 0 : Math.max(0, unreadCount);
			if (pw.activity_url) {
				this.activityUrl = pw.activity_url;
			}
			this.updateActivityUi();

			if (pw.completed_tasks && pw.completed_tasks.length > 0) {
				pw.completed_tasks.forEach(function (item) {
					var result = item.result || {};
					var resultChatId = parseInt(result.chat_id || 0, 10);
					var activeChatId = parseInt(PressArk.currentChatId || 0, 10);
					var canRenderInActiveChat = PressArk.isOpen && (
						resultChatId < 1 ||
						activeChatId < 1 ||
						activeChatId === resultChatId
					);

					if (resultChatId > 0 && activeChatId < 1) {
						PressArk.currentChatId = resultChatId;
					}

					if (canRenderInActiveChat) {
						PressArk.renderTaskResult(result);
					} else {
						PressArk.pendingResults = PressArk.pendingResults || [];
						PressArk.pendingResults.push(result);
					}
				});
			}

			var indexStatus = pw.index_status || {};
			var isIndexRebuilding = typeof indexStatus.running === 'boolean'
				? indexStatus.running
				: !!pw.index_rebuilding;

			if (isIndexRebuilding && PressArk.wasIndexRebuilding === undefined) {
				PressArk.wasIndexRebuilding = true;
			}
			if (!isIndexRebuilding && PressArk.wasIndexRebuilding) {
				PressArk.wasIndexRebuilding = false;
				PressArk.addMessage('ai', __( 'Content index rebuilt. I can now search your full site content.', 'pressark' ));
			}
		},

		renderTaskResult: function (result) {
			if (!result || typeof result !== 'object') return;

			if (this.isSilentContinuationResult(result)) {
				this.renderSilentContinuationStep(result);
			}

			if (this.continueCompactedRun(result)) {
				return;
			}

			var responseType = result.type || 'final_response';
			var replyText = result.reply || result.message || '';

			if (replyText && !this.isSilentContinuationResult(result)) {
				this.addMessage('ai', replyText, true);
				this.conversation.push({ role: 'assistant', content: replyText });
			}

			if (responseType === 'preview') {
				this.openPreview({
					preview_session_id: result.preview_session_id,
					preview_url: result.preview_url,
					diff: result.diff,
				});
			}

			if (result.pending_actions && result.pending_actions.length > 0) {
				for (var p = 0; p < result.pending_actions.length; p++) {
					this.renderPreviewCard(result.pending_actions[p], result.run_id || '', p);
				}
			}

			if (result.actions_performed && result.actions_performed.length > 0) {
				for (var i = 0; i < result.actions_performed.length; i++) {
					this.addActionResult(result.actions_performed[i]);
				}
			}

			this.applyResultState(result);

			if (result.suggestions) {
				this.renderSuggestionChips(result.suggestions);
			}

			this.autoSaveChat();
		},

		setToggleVisible: function (visible) {
			if (this.toggleBtn) {
				this.toggleBtn.style.opacity = visible ? '1' : '0';
				this.toggleBtn.style.pointerEvents = visible ? 'auto' : 'none';
				this.toggleBtn.style.transform = visible ? 'scale(1)' : 'scale(0.5)';
			}
			document.body.classList.toggle('pressark-panel-active', !visible);

			// On the frontend, push page content aside so it doesn't hide behind the panel.
			if ((window.pressarkData || {}).isFrontend) {
				document.body.style.marginRight = visible ? '' : '420px';
				document.body.style.transition = 'margin-right 0.3s cubic-bezier(0.16, 1, 0.3, 1)';
			}
		},

		restorePanelState: function () {
			// Inside a preview iframe — always start closed to avoid clutter.
			if (window.top !== window.self) {
				return;
			}

			var saved = sessionStorage.getItem(PANEL_STATE_KEY);
			if (saved === 'open') {
				this.panel.classList.add('pressark-panel-open');
				this.isOpen = true;
				this.setToggleVisible(false);

				// Show welcome if messages area is empty (mirrors open() logic).
				if (this.messagesEl.querySelectorAll('.pressark-message, .pressark-welcome').length === 0) {
					this.showWelcome();
				}
			}
		},

		/**
		 * Check for an auto-message from onboarding and send it.
		 */
		checkAutoMessage: function () {
			var autoMsg = sessionStorage.getItem('pressark_auto_message');
			if (!autoMsg) return;
			sessionStorage.removeItem('pressark_auto_message');
			if (!this.isOpen) {
				this.open();
			}
			var self = this;
			setTimeout(function () {
				self.inputEl.value = autoMsg;
				self.sendMessage();
			}, 400);
		},

		// ── Chat History (DB-backed) ──────────────────────────────────

		toggleHistory: function () {
			if (!this.historySidebar) return;
			var isOpen = this.historySidebar.style.display !== 'none' && this.historySidebar.style.display !== '';
			if (isOpen) {
				this.historySidebar.style.display = 'none';
			} else {
				this.historySidebar.style.display = 'block';
				this.loadChatList();
			}
		},

		loadChatList: function () {
			var self = this;
			var data = window.pressarkData;
			var listEl = document.getElementById('pressark-history-list');
			if (!listEl) return;

			listEl.innerHTML = '<div class="pressark-history-loading">' + this.escapeHtml(__( 'Loading...', 'pressark' )) + '</div>';

			fetch(data.restUrl + 'chats', {
				headers: { 'X-WP-Nonce': data.nonce }
			})
				.then(function (r) { return r.json(); })
				.then(function (chats) {
					if (!chats || chats.length === 0) {
						listEl.innerHTML = '<div class="pressark-history-empty">' + self.escapeHtml(__( 'No saved chats yet', 'pressark' )) + '</div>';
						return;
					}

					var html = '';
					for (var i = 0; i < chats.length; i++) {
						var c = chats[i];
						var isActive = self.currentChatId === parseInt(c.id, 10);
						html += '<div class="pressark-history-item' + (isActive ? ' pressark-history-active' : '') + '" data-chat-id="' + c.id + '">';
						html += '<span class="pressark-history-title">' + self.escapeHtml(c.title) + '</span>';
						html += '<span class="pressark-history-time">' + self.formatRelativeTime(c.updated_at) + '</span>';
						html += '<button class="pressark-history-delete" data-chat-id="' + c.id + '" title="' + self.escapeHtml(__( 'Delete', 'pressark' )) + '">&times;</button>';
						html += '</div>';
					}
					listEl.innerHTML = html;

					// Bind click handlers.
					var items = listEl.querySelectorAll('.pressark-history-item');
					for (var j = 0; j < items.length; j++) {
						(function (item) {
							item.addEventListener('click', function (e) {
								if (e.target.classList.contains('pressark-history-delete')) return;
								self.loadChat(parseInt(item.dataset.chatId, 10));
							});
						})(items[j]);
					}

					var delBtns = listEl.querySelectorAll('.pressark-history-delete');
					for (var k = 0; k < delBtns.length; k++) {
						(function (btn) {
							btn.addEventListener('click', function (e) {
								e.stopPropagation();
								self.deleteChat(parseInt(btn.dataset.chatId, 10));
							});
						})(delBtns[k]);
					}
				})
				.catch(function () {
					listEl.innerHTML = '<div class="pressark-history-empty">' + self.escapeHtml(__( 'Failed to load chats', 'pressark' )) + '</div>';
				});
		},

		loadChat: function (chatId) {
			var self = this;
			var data = window.pressarkData;

			fetch(data.restUrl + 'chats/' + chatId, {
				headers: { 'X-WP-Nonce': data.nonce }
			})
				.then(function (r) { return r.json(); })
				.then(function (chat) {
					if (!chat || chat.error) return;

					self.currentChatId = parseInt(chat.id, 10);
					self.conversation = [];
					self.loadedGroups = [];
					self.checkpoint = null;

					// Clear messages.
					self.messagesEl.innerHTML = '';

					// Restore messages from DB.
					var msgs = chat.messages || [];
					for (var i = 0; i < msgs.length; i++) {
						var msg = msgs[i];
						if (msg.role === 'user') {
							// Hide internal continuation messages from history display.
							if (msg.content && msg.content.indexOf('[Continue]') === 0) {
								self.conversation.push({ role: 'user', content: msg.content });
							} else {
								self.addMessage('user', msg.content, true);
								self.conversation.push({ role: 'user', content: msg.content });
							}
						} else if (msg.role === 'assistant' || msg.role === 'ai') {
							// Check if this is a serialised confirm/discard card.
							var staticCard = (msg.content && msg.content.indexOf('[PRESSARK_CARD:') === 0)
								? self.renderStaticCard(msg.content)
								: null;
							if (staticCard) {
								self.messagesEl.appendChild(staticCard);
							} else {
								self.addMessage('ai', msg.content, true);
							}
							self.conversation.push({ role: 'assistant', content: msg.content });
						}
					}

					self.scrollToBottom();

					// Close history panel.
					if (self.historySidebar) {
						self.historySidebar.style.display = 'none';
					}
				});
		},

		deleteChat: function (chatId) {
			var self = this;
			var data = window.pressarkData;

			fetch(data.restUrl + 'chats/' + chatId, {
				method: 'DELETE',
				headers: { 'X-WP-Nonce': data.nonce }
			})
				.then(function () {
					if (self.currentChatId === chatId) {
						self.currentChatId = null;
						self.newChat();
					}
					self.loadChatList();
				});
		},

		autoSaveChat: function () {
			var self = this;
			if (this.autoSaveTimer) clearTimeout(this.autoSaveTimer);

			this.autoSaveTimer = setTimeout(function () {
				self.saveCurrentChat();
			}, 2000);
		},

		saveCurrentChat: function () {
			if (this.conversation.length === 0) return;
			if (this.isSending && !this.currentChatId) return;

			var data = window.pressarkData;
			var body = {
				messages: this.conversation,
			};

			var savingChatId = this.currentChatId;

			if (savingChatId) {
				body.chat_id = savingChatId;
			}

			var self = this;

			fetch(data.restUrl + 'chats', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce
				},
				body: JSON.stringify(body)
			})
				.then(function (r) { return r.json(); })
				.then(function (result) {
					if (result.chat_id && !savingChatId && self.currentChatId === null) {
						self.currentChatId = result.chat_id;
					}
				})
				.catch(function () { /* silent fail */ });
		},

		newChat: function () {
			var prevConversation = this.conversation.slice();
			var prevChatId = this.currentChatId;

			this.currentChatId = null;
			this.conversation = [];
			this.loadedGroups = [];
			this.checkpoint = null;
			this.messagesEl.innerHTML = '';
			this.resetPlanTracker();

			if (prevConversation.length > 0 && prevChatId) {
				var data = window.pressarkData;
				fetch(data.restUrl + 'chats', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': data.nonce
					},
					body: JSON.stringify({
						chat_id: prevChatId,
						messages: prevConversation
					})
				}).catch(function () { /* silent */ });
			}

			this.showWelcome();
		},

		resetPlanTracker: function () {
			this.planTrackerState = {
				collapsed: false,
				hidden: false,
				runId: '',
				steps: [],
				summary: ''
			};
			this.renderPlanTracker();
		},

		showPlanTracker: function () {
			this.planTrackerState.hidden = false;
			this.renderPlanTracker();
		},

		hidePlanTracker: function () {
			this.planTrackerState.hidden = true;
			this.renderPlanTracker();
		},

		togglePlanTrackerCollapse: function () {
			if (!this.planTrackerState.steps.length) {
				return;
			}
			this.planTrackerState.hidden = false;
			this.planTrackerState.collapsed = !this.planTrackerState.collapsed;
			this.renderPlanTracker();
		},

		escapeHtmlToText: function (text) {
			var div = document.createElement('div');
			div.textContent = String(text || '');
			return div.innerHTML;
		},

		formatPlanSummaryHtml: function (text) {
			var clean = String(text || '').trim();
			if (!clean) {
				return this.escapeHtmlToText(__( 'Working the plan', 'pressark' ));
			}

			var parts = clean.split(/\s+/);
			if (parts.length < 2) {
				return '<em>' + this.escapeHtmlToText(clean) + '</em>';
			}

			return '<em>' + this.escapeHtmlToText(parts.shift()) + '</em> ' + this.escapeHtmlToText(parts.join(' '));
		},

		getPlanTrackerSummaryText: function (steps, fallback) {
			var activeText = '';
			for (var i = 0; i < steps.length; i++) {
				var status = this.normalizeStepStatus(steps[i].status);
				if (status === 'reading' || status === 'running' || status === 'active') {
					activeText = steps[i].text;
					break;
				}
			}
			if (activeText) {
				return activeText;
			}
			for (var j = 0; j < steps.length; j++) {
				if (this.normalizeStepStatus(steps[j].status) !== 'done' && this.normalizeStepStatus(steps[j].status) !== 'completed') {
					return steps[j].text;
				}
			}
			return fallback || (steps[steps.length - 1] ? steps[steps.length - 1].text : '');
		},

		getPlanProgressData: function (steps) {
			var completed = 0;
			var activeIndex = -1;
			for (var i = 0; i < steps.length; i++) {
				var status = this.normalizeStepStatus(steps[i].status);
				if (status === 'done' || status === 'completed') {
					completed++;
					continue;
				}
				if (activeIndex === -1) {
					activeIndex = i;
				}
			}
			if (activeIndex === -1 && steps.length > 0) {
				activeIndex = Math.max(steps.length - 1, 0);
			}
			return { completed: completed, activeIndex: activeIndex };
		},

		syncPlanTrackerFromPlan: function (planData) {
			if (!planData) {
				return;
			}
			var steps = this.normalizePlanSteps(planData);
			if (!steps.length) {
				return;
			}
			this.planTrackerState.runId = planData.run_id || planData.runId || this.planTrackerState.runId || '';
			this.planTrackerState.steps = steps;
			this.planTrackerState.summary = this.getPlanTrackerSummaryText(
				steps,
				(planData.request_summary || planData.message || planData.reply || '')
			);
			this.planTrackerState.hidden = false;
			this.renderPlanTracker();
		},

		syncPlanTrackerFromActivity: function (items) {
			if (!items || !items.length) {
				return;
			}
			var steps = [];
			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				if (!item) continue;
				var text = item.content || item.activeForm || item.label || item.tool || '';
				if (!text) continue;
				steps.push({
					status: item.status || 'pending',
					text: text
				});
			}
			if (!steps.length) {
				return;
			}
			this.planTrackerState.steps = steps;
			this.planTrackerState.summary = this.getPlanTrackerSummaryText(steps, this.planTrackerState.summary);
			this.planTrackerState.hidden = false;
			this.renderPlanTracker();
		},

		advancePlanTrackerFromStep: function (stepData) {
			if (!stepData || !this.planTrackerState.steps.length) {
				return;
			}

			var text = String(stepData.content || stepData.activeForm || stepData.label || stepData.tool || '').trim().toLowerCase();
			var nextStatus = stepData.status || 'pending';
			var steps = this.planTrackerState.steps.slice();
			var matchIndex = -1;

			for (var i = 0; i < steps.length; i++) {
				var candidate = String(steps[i].text || '').trim().toLowerCase();
				if (!candidate) continue;
				if (text && (candidate === text || candidate.indexOf(text) !== -1 || text.indexOf(candidate) !== -1)) {
					matchIndex = i;
					break;
				}
			}

			if (matchIndex === -1) {
				for (var j = 0; j < steps.length; j++) {
					var status = this.normalizeStepStatus(steps[j].status);
					if (status !== 'done' && status !== 'completed') {
						matchIndex = j;
						break;
					}
				}
			}

			if (matchIndex === -1) {
				return;
			}

			steps[matchIndex] = Object.assign({}, steps[matchIndex], { status: nextStatus });
			this.planTrackerState.steps = steps;
			this.planTrackerState.summary = this.getPlanTrackerSummaryText(steps, this.planTrackerState.summary);
			this.planTrackerState.hidden = false;
			this.renderPlanTracker();
		},

		renderPlanTracker: function () {
			if (!this.planTrackerEl || !this.planRestoreEl) {
				return;
			}

			var state = this.planTrackerState;
			var steps = Array.isArray(state.steps) ? state.steps : [];
			if (!steps.length) {
				this.planTrackerEl.hidden = true;
				this.planRestoreEl.hidden = true;
				return;
			}

			var progress = this.getPlanProgressData(steps);
			var total = steps.length;
			var percent = total > 0 ? Math.max(12, Math.round((progress.completed / total) * 100)) : 0;

			this.planTrackerEl.hidden = !!state.hidden;
			this.planRestoreEl.hidden = !state.hidden;
			this.planTrackerEl.classList.toggle('is-collapsed', !!state.collapsed);
			this.planTrackerEl.style.setProperty('--pressark-plan-progress-pct', percent + '%');

			if (this.planTrackerHeadEl) {
				this.planTrackerHeadEl.setAttribute('aria-expanded', state.collapsed ? 'false' : 'true');
			}
			if (this.planSummaryEl) {
				this.planSummaryEl.innerHTML = this.formatPlanSummaryHtml(state.summary);
			}
			if (this.planProgressEl) {
				this.planProgressEl.textContent = progress.completed + ' / ' + total;
			}
			if (this.planRestoreProgressEl) {
				this.planRestoreProgressEl.textContent = progress.completed + ' / ' + total;
			}
			if (this.planRestoreSummaryEl) {
				this.planRestoreSummaryEl.innerHTML = this.formatPlanSummaryHtml(state.summary);
			}
			if (this.planDotsEl) {
				this.planDotsEl.innerHTML = '';
				for (var i = 0; i < total; i++) {
					var dot = document.createElement('span');
					var status = this.normalizeStepStatus(steps[i].status);
					if (status === 'done' || status === 'completed') {
						dot.className = 'is-done';
					} else if (i === progress.activeIndex) {
						dot.className = 'is-active';
					}
					this.planDotsEl.appendChild(dot);
				}
			}
			if (this.planStepsEl) {
				this.planStepsEl.innerHTML = '';
				for (var j = 0; j < steps.length; j++) {
					var row = document.createElement('li');
					var rowStatus = this.normalizeStepStatus(steps[j].status);
					var className = rowStatus === 'running' ? 'step-active' : ('step-' + rowStatus);
					if (rowStatus === 'reading') {
						className = 'step-reading';
					} else if (rowStatus === 'done') {
						className = 'step-done';
					}
					row.className = className;
					row.innerHTML = '<span class="pressark-plan-step-text">' + this.escapeHtmlToText(steps[j].text) + '</span>';
					this.planStepsEl.appendChild(row);
				}
			}
		},

		formatRelativeTime: function (dateStr) {
			if (!dateStr) return '';
			var date = new Date(dateStr.replace(' ', 'T') + 'Z');
			var now = new Date();
			var diff = Math.floor((now - date) / 1000);

			if (diff < 60) return __( 'just now', 'pressark' );
			/* translators: %d: number of minutes ago. */
			if (diff < 3600) return sprintf( __( '%dm ago', 'pressark' ), Math.floor(diff / 60) );
			/* translators: %d: number of hours ago. */
			if (diff < 86400) return sprintf( __( '%dh ago', 'pressark' ), Math.floor(diff / 3600) );
			/* translators: %d: number of days ago. */
			if (diff < 604800) return sprintf( __( '%dd ago', 'pressark' ), Math.floor(diff / 86400) );
			return date.toLocaleDateString();
		},

		restoreConversation: function () {
			// Try to load the most recent chat from DB on next open.
		},

		// ── Welcome / Onboarding ──────────────────────────────────────

		getSparkMarkup: function () {
			return '<span class="pressark-spark-mark" aria-hidden="true">' +
				'<span class="pressark-spark-mark__ray pressark-spark-mark__ray-a">' +
				'<svg width="30" height="30" viewBox="0 0 24 24" fill="#EAF4FF"><path d="M12 1.5 13.7 9.3 21.5 11l-7.8 1.7L12 22.5 10.3 12.7 2.5 11l7.8-1.7L12 1.5z"/></svg>' +
				'</span>' +
				'<span class="pressark-spark-mark__core"></span>' +
				'</span>';
		},

		showWelcome: function () {
			var data = window.pressarkData;
			var isFirstTime = !data.isOnboarded;
			var hasWoo = data.hasWooCommerce;
			var welcomeTitle = isFirstTime
				? sprintf(
					/* translators: %s: emphasized welcome phrase. */
					this.escapeHtml(__( 'Welcome to PressArk, %s', 'pressark' )),
					'<em>' + this.escapeHtml(__( 'your WordPress co-pilot.', 'pressark' )) + '</em>'
				)
				: sprintf(
					/* translators: %s: emphasized greeting phrase. */
					this.escapeHtml(__( 'Good to see you - %s', 'pressark' )),
					'<em>' + this.escapeHtml(__( 'what shall we ship today?', 'pressark' )) + '</em>'
				);

			var welcome = document.createElement('div');
			welcome.className = 'pressark-welcome';
			welcome.innerHTML =
				'<div class="pressark-welcome-icon">' +
				this.getSparkMarkup() +
				'</div>' +
				'<div class="pressark-welcome-title">' +
				welcomeTitle +
				'</div>' +
				'<div class="pressark-welcome-subtitle">' +
				this.escapeHtml(
				(isFirstTime
					? __( 'Ask anything, or start with a focused action built for the page you are on.', 'pressark' )
					: __( 'I\'m caught up on your site. Pick a useful starting point or ask directly.', 'pressark' ))
				) +
				'</div>';

			this.messagesEl.appendChild(welcome);

			if (isFirstTime) {
				data.isOnboarded = true;
			}

			this.showSuggestions(hasWoo);
		},

		showSuggestions: function (hasWoo) {
			var self = this;
			var container = document.createElement('div');
			container.className = 'pressark-suggestions';
			container.innerHTML =
				'<div class="pressark-suggestions-heading">' + this.escapeHtml(__( 'Made for this page', 'pressark' )) + '</div>' +
				'<div class="pressark-suggestion-grid"></div>' +
				'<div class="pressark-suggestions-heading pressark-suggestions-heading--quick">' + this.escapeHtml(__( 'Quick actions', 'pressark' )) + '</div>' +
				'<div class="pressark-suggestion-list"></div>';

			var allSuggestions = [
				{ iconName: 'pen', tone: 'blue', label: __( 'Draft a post brief', 'pressark' ), desc: __( 'Title, outline, SEO angle', 'pressark' ), message: __( 'Write a new blog post with an SEO-optimized title, meta description, outline, and engaging content that matches my brand voice', 'pressark' ) },
				{ iconName: 'search', tone: 'teal', label: __( 'Audit this page', 'pressark' ), desc: __( 'Headings, metadata, links', 'pressark' ), message: __( 'Run a comprehensive SEO audit on the current page. Check meta tags, headings, internal links, alt text, and give me a prioritized fix list', 'pressark' ) },
				{ iconName: 'sparkles', tone: 'violet', label: __( 'Rewrite for clarity', 'pressark' ), desc: __( 'Tighter copy, same tone', 'pressark' ), message: __( 'Review the current page content and rewrite it to be clearer, more compelling, conversion-focused, and SEO-friendly while keeping my brand voice', 'pressark' ) },
				{ iconName: 'barChart', tone: 'amber', label: __( 'Find growth gaps', 'pressark' ), desc: __( 'Content that needs attention', 'pressark' ), message: __( 'Analyze my published content and identify which posts need updating, better SEO, stronger CTAs, or more engagement hooks', 'pressark' ) },
				{ iconName: 'shield', tone: 'rose', label: __( 'Security scan', 'pressark' ), desc: __( 'Risks and outdated pieces', 'pressark' ), message: __( 'Scan my site for security vulnerabilities and outdated components, then suggest fixes', 'pressark' ) },
				{ iconName: 'refresh', tone: 'blue', label: __( 'Bulk find & replace', 'pressark' ), desc: __( 'Update stale copy or links', 'pressark' ), message: __( 'Find and replace text, links, or outdated references across all my pages and posts', 'pressark' ) },
				{ iconName: 'broom', tone: 'teal', label: __( 'Site cleanup', 'pressark' ), desc: __( 'Revisions, spam, transients', 'pressark' ), message: __( 'Clean up my database by removing post revisions, spam comments, orphaned metadata, and transient data', 'pressark' ) },
				{ iconName: 'clipboard', tone: 'violet', label: __( 'Content overview', 'pressark' ), desc: __( 'Status, word count, freshness', 'pressark' ), message: __( 'Give me a complete overview of all my content: pages, posts, publish status, word count, and last updated date', 'pressark' ) },
			];

			if (hasWoo) {
				allSuggestions.splice(2, 0,
					{ iconName: 'store', tone: 'amber', label: __( 'Store health check', 'pressark' ), desc: __( 'Inventory, product gaps, fixes', 'pressark' ), message: __( 'Analyze my WooCommerce store health. Check inventory levels, missing product data, and optimization opportunities', 'pressark' ) },
					{ iconName: 'trendUp', tone: 'teal', label: __( 'Product optimizer', 'pressark' ), desc: __( 'Titles, descriptions, SEO', 'pressark' ), message: __( 'Review my products and improve titles, descriptions, and SEO metadata for better search visibility and conversions', 'pressark' ) }
				);
			}

			var grid = container.querySelector('.pressark-suggestion-grid');
			var list = container.querySelector('.pressark-suggestion-list');
			var suggestions = allSuggestions.slice(0, 8);

			for (var i = 0; i < suggestions.length; i++) {
				(function (s) {
					var btn = document.createElement('button');
					var isQuick = i >= 4;
					btn.className = 'pressark-suggestion pressark-suggestion--' + (s.tone || 'blue') + (isQuick ? ' pressark-suggestion--row' : '');
					btn.innerHTML =
						pwIcon(s.iconName, s.tone) +
						'<span class="pressark-suggestion-copy">' +
						'<span class="pressark-suggestion-title">' + self.escapeHtml(s.label) + '</span>' +
						'<span class="pressark-suggestion-desc">' + self.escapeHtml(s.desc || '') + '</span>' +
						'</span>' +
						(isQuick ? '<span class="pressark-suggestion-arrow" aria-hidden="true">' + pwIcons.arrowRight + '</span>' : '');
					btn.addEventListener('click', function () {
						self.inputEl.value = s.message;
						self.sendMessage();
						var sugs = self.messagesEl.querySelectorAll('.pressark-suggestions');
						for (var j = 0; j < sugs.length; j++) {
							sugs[j].remove();
						}
					});
					(isQuick ? list : grid).appendChild(btn);
				})(suggestions[i]);
			}

			this.messagesEl.appendChild(container);
			this.messagesEl.scrollTop = 0;
		},

		renderSuggestionChips: function (suggestions) {
			if (!suggestions || !suggestions.length) return;
			var self = this;
			var container = document.createElement('div');
			container.className = 'pressark-suggestions pressark-suggestion-chips';

			var count = Math.min(suggestions.length, 3);
			for (var i = 0; i < count; i++) {
				(function (text) {
					var chip = document.createElement('button');
					chip.className = 'pressark-chip';
					chip.textContent = text;
					chip.addEventListener('click', function () {
						self.inputEl.value = text;
						self.sendMessage();
					});
					container.appendChild(chip);
				})(suggestions[i]);
			}

			this.messagesEl.appendChild(container);
			this.scrollToBottom();
		},

		// ── Timestamps ────────────────────────────────────────────────

		maybeAddTimestamp: function () {
			var now = Date.now();
			if (this.lastMessageTime && (now - this.lastMessageTime) > 5 * 60 * 1000) {
				var tsEl = document.createElement('div');
				tsEl.className = 'pressark-timestamp';
				var d = new Date(now);
				var hours = d.getHours();
				var minutes = d.getMinutes();
				var ampm = hours >= 12 ? 'PM' : 'AM';
				hours = hours % 12 || 12;
				minutes = minutes < 10 ? '0' + minutes : minutes;
				tsEl.textContent = '\u2014 ' + hours + ':' + minutes + ' ' + ampm + ' \u2014';
				this.messagesEl.appendChild(tsEl);
			}
			this.lastMessageTime = now;
		},

		// ── Message Rendering ─────────────────────────────────────────

		autoGrow: function () {
			this.inputEl.style.height = 'auto';
			this.inputEl.style.height = Math.min(this.inputEl.scrollHeight, 120) + 'px';
		},

		/**
		 * Strip any remaining JSON code blocks from AI message text.
		 */
		cleanMessageContent: function (text) {
			text = text.replace(/```(?:json)?[\s\S]*?```/g, '');
			text = text.replace(/\{\s*"actions"\s*:\s*\[[\s\S]*\]\s*\}\s*$/g, '');
			return text.trim();
		},

		/**
		 * Render text with markdown-like formatting.
		 */
		renderFormattedMessage: function (text) {
			text = this.cleanMessageContent(text);

			// Escape HTML first — full entity escaping including quotes
			// to prevent attribute injection via crafted markdown links.
			var escaped = text
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&#39;');

			// Code blocks (``` ... ```).
			escaped = escaped.replace(/```(\w*)\n?([\s\S]*?)```/g, function (m, lang, code) {
				return '<pre class="pressark-code-block"><code>' + code.trim() + '</code></pre>';
			});

			// Inline code (`...`).
			escaped = escaped.replace(/`([^`\n]+)`/g, '<code class="pressark-inline-code">$1</code>');

			// Headers (### ... or ## ... or # ...).
			escaped = escaped.replace(/^### (.+)$/gm, '<strong class="pressark-h3">$1</strong>');
			escaped = escaped.replace(/^## (.+)$/gm, '<strong class="pressark-h2">$1</strong>');
			escaped = escaped.replace(/^# (.+)$/gm, '<strong class="pressark-h1">$1</strong>');

			// Bold (**text** or __text__).
			escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
			escaped = escaped.replace(/__(.+?)__/g, '<strong>$1</strong>');

			// Italic (*text* or _text_) — careful not to match bold markers.
			escaped = escaped.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');

			// Unordered list items (- item or * item).
			escaped = escaped.replace(/^[\-\*] (.+)$/gm, '<span class="pressark-list-item">\u2022 $1</span>');

			// Ordered list items (1. item).
			escaped = escaped.replace(/^(\d+)\. (.+)$/gm, '<span class="pressark-list-item">$1. $2</span>');

			// Links [text](url) — only allow http/https URLs.
			// Reject URLs containing whitespace or unescaped control chars.
			var self = this;
			escaped = escaped.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, function (m, linkText, url) {
				// Strip any residual entity-decoded quotes or dangerous chars from the URL.
				if (/[\s<>]/.test(url) || url.indexOf('javascript:') === 0) {
					return linkText;
				}
				return '<a href="' + url + '" target="_blank" rel="noopener">' + linkText + '</a>';
			});

			// Newlines.
			escaped = escaped.replace(/\n/g, '<br>');

			return escaped;
		},

		addMessage: function (type, text, skipSave) {
			// Remove suggestion chips and welcome on first user message.
			if (type === 'user') {
				var sugs = this.messagesEl.querySelectorAll('.pressark-suggestions');
				for (var i = 0; i < sugs.length; i++) {
					sugs[i].remove();
				}
				var welcomes = this.messagesEl.querySelectorAll('.pressark-welcome');
				for (var w = 0; w < welcomes.length; w++) {
					welcomes[w].remove();
				}
			}

			this.maybeAddTimestamp();

			var msgEl = document.createElement('div');
			msgEl.dataset.timestamp = String(Date.now());

			if (type === 'ai') {
				msgEl.className = 'pressark-message pressark-message-assistant';
				var images = (window.pressarkData && window.pressarkData.images) || {};
				var logoSrc = this.findImage(images, ['WHITE-APP-LOGO', 'icon', 'app-icon']);
				msgEl.innerHTML =
					'<div class="pressark-ai-label">' +
					(logoSrc ? '<img src="' + logoSrc + '" alt="PressArk">' : '') +
					'<span>PressArk</span>' +
					'</div>' +
					'<div class="pressark-message-content">' + this.renderFormattedMessage(text) + '</div>';
			} else if (type === 'error') {
				msgEl.className = 'pressark-message pressark-message-error';
				msgEl.innerHTML = this.renderErrorMessage(text);
			} else if (type === 'user') {
				msgEl.className = 'pressark-message pressark-message-user';
				var contentDiv = document.createElement('div');
				contentDiv.className = 'pressark-message-content';
				contentDiv.textContent = text;
				msgEl.appendChild(contentDiv);
			} else {
				msgEl.className = 'pressark-message pressark-message-system';
				var contentDiv2 = document.createElement('div');
				contentDiv2.className = 'pressark-message-content';
				contentDiv2.textContent = text;
				msgEl.appendChild(contentDiv2);
			}

			this.messagesEl.appendChild(msgEl);
			this.scrollToBottom();

			// Errors are ephemeral UI artifacts — never persist them as chat
			// history. Otherwise pre-flight gates like the missing-API-key
			// banner end up stored as user messages, polluting the next run's
			// conversation context (the prompt then sees the error string
			// instead of the user's actual goal).
			if (!skipSave && type !== 'error') {
				this.autoSaveChat();
			}

			return msgEl;
		},

		renderErrorMessage: function (text) {
			var html = '<span class="pressark-error-icon">' + pwIcons.warning + '</span>';
			html += '<span class="pressark-message-content">' + this.escapeHtml(text) + '</span>';
			html += '<button class="pressark-retry-btn">' + this.escapeHtml(__( 'Retry', 'pressark' )) + '</button>';
			return html;
		},

		appendRetryableError: function (text, skipSave) {
			var msgEl = this.addMessage('error', text, skipSave);
			if (msgEl) {
				this.bindRetryButton(msgEl.querySelector('.pressark-retry-btn'));
			}
			return msgEl;
		},

		cleanupStreamingBubbleContent: function (bubble) {
			if (!bubble) return null;

			var contentEl = bubble.querySelector('.pressark-message-content');
			if (!contentEl) return null;

			var inlineSteps = contentEl.querySelectorAll('.pressark-inline-step');
			for (var i = 0; i < inlineSteps.length; i++) {
				inlineSteps[i].remove();
			}

			var segs = contentEl.querySelectorAll('.pressark-stream-text-segment');
			for (var j = 0; j < segs.length; j++) {
				while (segs[j].firstChild) {
					contentEl.insertBefore(segs[j].firstChild, segs[j]);
				}
				segs[j].remove();
			}

			return contentEl;
		},

		renderInterruptedStream: function (bubble, message) {
			this._streamText = '';
			this._streamSegmentText = '';

			if (bubble) {
				bubble.classList.remove('pressark-message-streaming');
			}

			var contentEl = this.cleanupStreamingBubbleContent(bubble);
			var hasRenderableContent = !!(
				contentEl &&
				(
					(contentEl.textContent && contentEl.textContent.trim()) ||
					contentEl.children.length > 0
				)
			);

			if (bubble && !hasRenderableContent && bubble.parentNode) {
				bubble.parentNode.removeChild(bubble);
			}

			this.appendRetryableError(message, true);
		},

		appendAssistantResultMessage: function (text, result, skipSave) {
			if (!text) return null;

			var msgEl = this.addMessage('ai', text, skipSave);
			this.decorateAssistantMessage(msgEl, result);
			return msgEl;
		},

		presentResult: function (result, options) {
			options = options || {};
			var silentContinuation = !!options.silentContinuation;
			var responseType = result.type || 'final_response';

			if (responseType === 'permission_required') {
				var permissionReply = result.reply || result.message || __( 'This action needs permission before it can run.', 'pressark' );
				if (result.upgrade_prompt) {
					var permissionUpgradeUrl = (result.upgrade_url || window.pressarkData.upgradeUrl || '#');
					permissionReply += '\n\n[' + __( 'Manage billing', 'pressark' ) + '](' + permissionUpgradeUrl + ')';
				}
				if (permissionReply) {
					this.appendAssistantResultMessage(permissionReply, result);
					this.conversation.push({ role: 'assistant', content: permissionReply });
				}
			} else if (responseType === 'queued') {
				this.pendingTaskCount = Math.max(this.pendingTaskCount, 1);
				this.syncTaskPolling(true);
				this.appendAssistantResultMessage(result.message || __( 'Working on that in the background...', 'pressark' ), result);
				this.conversation.push({ role: 'assistant', content: result.message || '' });
			} else if (responseType === 'preview') {
				if (result.reply) {
					this.appendAssistantResultMessage(result.reply, result);
					this.conversation.push({ role: 'assistant', content: result.reply });
				}
				this.openPreview({
					preview_session_id: result.preview_session_id,
					preview_url: result.preview_url,
					diff: result.diff,
					risk_receipt: result.risk_receipt,
				});
			} else if (responseType === 'confirm_card') {
				if (result.reply) {
					this.appendAssistantResultMessage(result.reply, result);
					this.conversation.push({ role: 'assistant', content: result.reply });
				}
				if (result.pending_actions && result.pending_actions.length > 0) {
					for (var p = 0; p < result.pending_actions.length; p++) {
						this.renderPreviewCard(result.pending_actions[p], result.run_id || '', p);
					}
				}
			} else if (responseType === 'plan_ready') {
				var planReply = result.reply || result.message || __( 'Plan ready. Review the checklist below, then approve, revise, or cancel.', 'pressark' );
				var planHost = null;
				if (planReply && !silentContinuation) {
					var planMsg = this.appendAssistantResultMessage(planReply, result);
					planHost = planMsg ? planMsg.querySelector('.pressark-message-content') : null;
					this.conversation.push({ role: 'assistant', content: planReply });
				}
				this.renderPlanReadyCard(result, planHost || undefined);
			} else {
				var reply = result.reply || result.message || (result.is_error ? __( 'Something went wrong.', 'pressark' ) : '');
				if (reply && !silentContinuation) {
					this.appendAssistantResultMessage(reply, result);
					this.conversation.push({ role: 'assistant', content: reply });
				}

				if (result.pending_actions && result.pending_actions.length > 0) {
					for (var p2 = 0; p2 < result.pending_actions.length; p2++) {
						this.renderPreviewCard(result.pending_actions[p2], result.run_id || '', p2);
					}
				}

				if (result.actions_performed && result.actions_performed.length > 0) {
					for (var i = 0; i < result.actions_performed.length; i++) {
						this.addActionResult(result.actions_performed[i]);
					}
				}

				// v5.8.2 (2026-05-13, iter-38): server signals that any earlier
				// Plan Mode card in this chat is obsolete (model concluded the
				// requested state is already satisfied — no plan needed).
				if (result.plan_card_obsolete === true) {
					this.removeObsoletePlanCards(result.run_id || '');
				}
			}

			this.applyResultState(result);

			if (result.suggestions) {
				this.renderSuggestionChips(result.suggestions);
			}

			this.autoSaveChat();
		},

		normalizePlanSteps: function (planData) {
			var rawSteps = [];
			if (Array.isArray(planData)) {
				rawSteps = planData;
			} else if (planData && Array.isArray(planData.steps)) {
				rawSteps = planData.steps;
			} else if (planData && Array.isArray(planData.plan_steps)) {
				rawSteps = planData.plan_steps;
			} else if (planData && typeof planData.plan_markdown === 'string' && planData.plan_markdown) {
				var planLines = planData.plan_markdown.split(/\r?\n/);
				for (var i = 0; i < planLines.length; i++) {
					var match = planLines[i].match(/^\s*\d+\.\s+(.+)$/);
					if (match && match[1]) {
						rawSteps.push(match[1]);
					}
				}
			}

			var normalized = [];
			for (var s = 0; s < rawSteps.length; s++) {
				var step = rawSteps[s];
				if (typeof step === 'string') {
					if (step.trim()) {
						normalized.push({ status: 'pending', text: step.trim() });
					}
					continue;
				}
				if (!step || typeof step !== 'object') {
					continue;
				}
				// Phase 3b plan-step shape uses TodoWrite-style `content` + `activeForm`.
				// Fall back to legacy text/label/title for older run snapshots.
				var text = step.content || step.activeForm || step.text || step.label || step.title || '';
				if (!text) {
					continue;
				}
				normalized.push({
					status: step.status || 'pending',
					text: text
				});
			}

			return normalized;
		},

		// v5.8.2 (2026-05-13, iter-38): server-signaled cleanup of obsolete
		// Plan Mode cards. When the model concludes a chain with "no action
		// needed" after a round-1 speculative plan was streamed, the server
		// sets result.plan_card_obsolete=true. We disable the actionable
		// buttons on any matching card so the user sees the plan as
		// "considered but not needed" rather than "click Execute".
		//
		// Why disable in place rather than remove: the plan card is part of
		// the conversation history (operator audit trail). Removing it would
		// leave the model's "no changes needed" text floating without
		// context. Disabling preserves the audit trail and removes the
		// misleading call-to-action.
		removeObsoletePlanCards: function (runId, hostEl) {
			var roots = [];
			if (hostEl) { roots.push(hostEl); }
			if (this.messagesEl) { roots.push(this.messagesEl); }
			var seen = {};
			for (var r = 0; r < roots.length; r++) {
				var cards = roots[r].querySelectorAll('.pressark-plan-card');
				for (var i = 0; i < cards.length; i++) {
					var card = cards[i];
					if (seen[card.dataset.pressarkObsoleteApplied || '']) {
						continue;
					}
					if (runId && card.dataset.runId && card.dataset.runId !== runId) {
						continue;
					}
					if (card.classList.contains('pressark-plan-card-obsolete')) {
						continue;
					}
					card.classList.add('pressark-plan-card-obsolete');
					var actions = card.querySelector('.pressark-plan-actions');
					if (actions) {
						actions.parentNode.removeChild(actions);
					}
					var revisionWrap = card.querySelector('.pressark-plan-revision-wrap');
					if (revisionWrap) {
						revisionWrap.parentNode.removeChild(revisionWrap);
					}
					var summary = card.querySelector('.pressark-plan-summary');
					var notNeededLabel = __( 'not needed', 'pressark' );
					if (summary && summary.textContent.indexOf(notNeededLabel) === -1) {
						summary.textContent = summary.textContent + ' - ' + notNeededLabel;
					}
					card.dataset.pressarkObsoleteApplied = '1';
				}
			}
		},

		renderPlanReadyCard: function (planData, hostEl) {
			if (!planData) return null;

			var container = hostEl || this.messagesEl;
			if (!container) return null;
			if (container.classList && container.classList.contains('pressark-message-content')) {
				container.classList.add('pressark-message-content--planning');
			}

			var steps = this.normalizePlanSteps(planData);
			var runId = planData.run_id || planData.runId || '';
			var approveEndpoint = planData.approve_endpoint || planData.approveEndpoint || planData.execute_endpoint || planData.executeEndpoint || '';
			var executeEndpoint = planData.execute_endpoint || planData.executeEndpoint || approveEndpoint || '';
			var reviseEndpoint = planData.revise_endpoint || planData.reviseEndpoint || '';
			var rejectEndpoint = planData.reject_endpoint || planData.rejectEndpoint || '';
			var approvalLevel = String(planData.approval_level || planData.approvalLevel || '');
			var planPhase = String(planData.plan_phase || planData.planPhase || (approveEndpoint || reviseEndpoint || rejectEndpoint ? 'planning' : 'executing'));
			var artifact = planData.plan_artifact && typeof planData.plan_artifact === 'object' ? planData.plan_artifact : {};
			var summaryText = artifact.request_summary || planData.request_summary || planData.reply || planData.message || '';
			var planVersion = artifact.version ? String(artifact.version) : '';
			var canExecute = !!approveEndpoint && planData.can_execute !== false && steps.length > 0;
			var isExecutionOnly = planPhase === 'executing' && !canExecute && !reviseEndpoint && !rejectEndpoint;
			if (!summaryText) {
				summaryText = isExecutionOnly ? __( 'Working through the current checklist.', 'pressark' ) : __( 'Plan ready.', 'pressark' );
			}
			var existing = null;
			var cards = container.querySelectorAll('.pressark-plan-card');

			for (var i = 0; i < cards.length; i++) {
				if (runId && cards[i].dataset.runId === runId) {
					existing = cards[i];
					break;
				}
			}

			var card = existing || document.createElement('div');
			card.className = 'pressark-plan-card';
			if (runId) {
				card.dataset.runId = runId;
			}

			var stepsHtml = '';
			for (var s = 0; s < steps.length; s++) {
				stepsHtml += '<li class="step-' + this.escapeHtml(steps[s].status || 'pending') + '"><span class="pressark-plan-step-text">' + this.escapeHtml(steps[s].text) + '</span></li>';
			}

			var summary = isExecutionOnly ? __( 'Execution plan', 'pressark' ) : __( 'Plan ready', 'pressark' );
			if (steps.length > 0) {
				/* translators: %d: number of plan steps. */
				summary += ' - ' + sprintf( _n( '%d step', '%d steps', steps.length, 'pressark' ), steps.length );
			}

			var phaseLabelMap = {
				exploring: __( 'Exploring', 'pressark' ),
				planning: __( 'Planning', 'pressark' ),
				ready: __( 'Ready', 'pressark' ),
				executing: __( 'Executing', 'pressark' )
			};
			var phaseLabel = phaseLabelMap[planPhase] || __( 'Planning', 'pressark' );
			var approvalLabel = approvalLevel === 'soft' ? __( 'Soft plan', 'pressark' ) : (approvalLevel === 'hard' ? __( 'Hard approval', 'pressark' ) : '');
			var approveLabel = approvalLevel === 'soft' ? __( 'Execute', 'pressark' ) : __( 'Approve & Execute', 'pressark' );

			var bodyHtml = '';
			bodyHtml +=
				'<div class="pressark-plan-meta">' +
				'<span class="pressark-plan-badge pressark-plan-phase">' + this.escapeHtml(phaseLabel) + '</span>' +
				(approvalLabel ? '<span class="pressark-plan-badge pressark-plan-approval">' + this.escapeHtml(approvalLabel) + '</span>' : '') +
				(planVersion ? '<span class="pressark-plan-badge pressark-plan-version">v' + this.escapeHtml(planVersion) + '</span>' : '') +
				'</div>';

			if (summaryText) {
				bodyHtml += '<div class="pressark-plan-description">' + this.escapeHtml(summaryText) + '</div>';
			}

			if (stepsHtml) {
				bodyHtml += '<ol class="pressark-plan-steps">' + stepsHtml + '</ol>';
			}

			if (runId && (canExecute || reviseEndpoint || rejectEndpoint)) {
				bodyHtml +=
					'<div class="pressark-plan-revision-wrap">' +
					'<div class="pressark-plan-refine-row">' +
					'<button type="button" class="pressark-plan-refine-back" aria-label="' + this.escapeHtml(__( 'Back', 'pressark' )) + '">' + pwIcons.undo + '</button>' +
					'<textarea class="pressark-plan-revision-note" rows="1" placeholder="' + this.escapeHtml(__( 'What should I adjust?', 'pressark' )) + '"></textarea>' +
					'<button type="button" class="pressark-plan-refine-send" aria-label="' + this.escapeHtml(__( 'Send refinement', 'pressark' )) + '">' + pwIcons.send + '</button>' +
					'</div>' +
					'</div>';
				bodyHtml +=
					'<div class="pressark-preview-actions pressark-plan-actions">' +
					(rejectEndpoint
						? '<button type="button" class="pressark-preview-cancel pressark-plan-decline">' + this.escapeHtml(__( 'Decline', 'pressark' )) + '</button>'
						: '') +
					(reviseEndpoint
						? '<button type="button" class="pressark-plan-revise">' + this.escapeHtml(__( 'Refine', 'pressark' )) + '</button>'
						: '') +
					(canExecute
						? '<button type="button" class="pressark-preview-confirm pressark-plan-approve">' + this.escapeHtml(approveLabel) + '</button>'
						: '') +
					'</div>';
				bodyHtml += '<div class="pressark-plan-action-status" aria-live="polite"></div>';
			}

			card.innerHTML =
				'<div class="pressark-plan-header">' +
				'<span class="pressark-plan-summary">' + this.escapeHtml(summary) + '</span>' +
				'</div>' +
				bodyHtml;
			card.dataset.refining = 'false';

			var self = this;
			var header = card.querySelector('.pressark-plan-header');
			if (header) {
				header.addEventListener('click', function (event) {
					if (event.target && event.target.closest && event.target.closest('.pressark-plan-actions, .pressark-plan-revision-wrap')) {
						return;
					}
					card.classList.toggle('collapsed');
				});
			}

			var approveBtn = card.querySelector('.pressark-plan-approve');
			if (approveBtn) {
				approveBtn.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					self.executePlan(runId, card, approveEndpoint || executeEndpoint);
				});
			}

			var reviseBtn = card.querySelector('.pressark-plan-revise');
			if (reviseBtn) {
				reviseBtn.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					card.dataset.refining = 'true';
					var input = card.querySelector('.pressark-plan-revision-note');
					if (input) {
						setTimeout(function () { input.focus(); }, 40);
					}
				});
			}

			var rejectBtn = card.querySelector('.pressark-plan-decline');
			if (rejectBtn) {
				rejectBtn.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					self.rejectPlan(runId, card, rejectEndpoint);
				});
			}

			var refineBackBtn = card.querySelector('.pressark-plan-refine-back');
			if (refineBackBtn) {
				refineBackBtn.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					card.dataset.refining = 'false';
					var input = card.querySelector('.pressark-plan-revision-note');
					if (input) {
						input.value = '';
					}
				});
			}

			var refineSendBtn = card.querySelector('.pressark-plan-refine-send');
			if (refineSendBtn) {
				refineSendBtn.addEventListener('click', function (event) {
					event.preventDefault();
					event.stopPropagation();
					self.revisePlan(runId, card, reviseEndpoint);
				});
			}

			if (!existing) {
				container.appendChild(card);
			}

			this.syncPlanTrackerFromPlan(planData);
			this.scrollToBottom();
			return card;
		},

		getPlanRevisionNote: function (card) {
			if (!card) return '';
			var input = card.querySelector('.pressark-plan-revision-note');
			return input ? String(input.value || '').trim() : '';
		},

		setPlanActionState: function (card, state, message, disableControls) {
			if (!card) return;
			if (state !== 'pending') {
				card.dataset.refining = 'false';
			}
			var controls = card.querySelectorAll('.pressark-plan-approve, .pressark-plan-revise, .pressark-plan-decline, .pressark-plan-refine-back, .pressark-plan-refine-send, .pressark-plan-revision-note');
			for (var i = 0; i < controls.length; i++) {
				controls[i].disabled = !!disableControls;
			}

			var statusEl = card.querySelector('.pressark-plan-action-status');
			if (!statusEl) return;

			if (!message) {
				statusEl.innerHTML = '';
				return;
			}

			if (state === 'pending') {
				statusEl.innerHTML =
					'<div class="pressark-confirm-stream">' +
					'<div class="pressark-confirm-stream__label">' + this.escapeHtml(message) + '</div>' +
					'<div class="pressark-confirm-stream__body"></div>' +
					'</div>';
				return;
			}

			statusEl.innerHTML =
				'<div class="pressark-action-result ' + (state === 'success' ? 'pressark-action-success' : 'pressark-action-fail') + '">' +
				'<span>' + (state === 'success' ? pwIcon('check') : pwIcon('x')) + ' ' + this.escapeHtml(message) + '</span>' +
				'</div>';
		},

		performPlanAction: function (runId, endpoint, payload, card, options) {
			if (!runId) {
				return Promise.resolve({ success: false, message: __( 'Missing plan run ID.', 'pressark' ) });
			}

			var self = this;
			var data = window.pressarkData || {};
			var requestOptions = options || {};
			var url = endpoint || (data.restUrl + (requestOptions.path || 'plan/execute'));
			var body = Object.assign({ run_id: runId }, payload || {});

			this.setPlanActionState(card, 'pending', requestOptions.pendingLabel || __( 'Working...', 'pressark' ), true);
			this.beginPassiveRequest();

			return fetch(url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce
				},
				body: JSON.stringify(body)
			})
				.then(function (response) { return response.json(); })
				.then(function (result) {
					self.finishPassiveRequest();

					if (result && !result.error) {
						self.setPlanActionState(card, 'success', requestOptions.successMessage || __( 'Action completed.', 'pressark' ), true);
						self.presentResult(result);
					} else {
						self.setPlanActionState(
							card,
							'error',
							(result && (result.message || result.error)) || requestOptions.failureMessage || __( 'Plan action failed.', 'pressark' ),
							false
						);
						if (result && result.message) {
							self.appendRetryableError(result.message, true);
						}
					}

					return result;
				})
				.catch(function () {
					self.finishPassiveRequest();
					self.setPlanActionState(card, 'error', __( 'Network error. Please try again.', 'pressark' ), false);
					self.appendRetryableError(__( 'Network error. Please try again.', 'pressark' ), true);
					return { success: false, message: __( 'Network error. Please try again.', 'pressark' ) };
				});
		},

		executePlan: function (runId, card, executeEndpoint) {
			if (window.pressarkData && window.pressarkData.streamingEnabled !== false) {
				return this.executePlanStream(runId, card, executeEndpoint);
			}

			return this.performPlanAction(
				runId,
				executeEndpoint,
				{},
				card,
				{
					path: 'plan/execute',
					pendingLabel: __( 'Running execute phase...', 'pressark' ),
					successMessage: __( 'Execution started. Review the response below.', 'pressark' ),
					failureMessage: __( 'Failed to start execution.', 'pressark' )
				}
			);
		},

		executePlanStream: function (runId, card, executeEndpoint) {
			if (!runId) {
				return Promise.resolve({ success: false, message: __( 'Missing plan run ID.', 'pressark' ) });
			}
			if (this.isSending || this._confirmStreamActive) {
				return Promise.resolve({ success: false, message: __( 'Another request is already running.', 'pressark' ) });
			}

			var self = this;
			var data = window.pressarkData || {};
			var streamEndpoint = (executeEndpoint || '').replace(/\/plan\/execute$/, '/plan/approve-stream')
				.replace(/\/plan\/approve$/, '/plan/approve-stream');
			if (!streamEndpoint) {
				streamEndpoint = (data.restUrl || '') + 'plan/approve-stream';
			}

			this.setPlanActionState(card, 'pending', __( 'Executing approved plan...', 'pressark' ), true);

			var controller = this.beginRequest();
			this.showTyping(__( 'Executing approved plan', 'pressark' ));

			var bubble = null;
			var textBuffer = '';
			this._streamGotContent = false;
			this._streamSegmentText = '';

			return fetch(streamEndpoint, {
				method: 'POST',
				signal: controller.signal,
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce
				},
				body: JSON.stringify({ run_id: runId })
			}).then(function (response) {
				if (!response.ok || !response.body) {
					self.finishRequest();
					return self.performPlanAction(
						runId,
						executeEndpoint,
						{},
						card,
						{
							path: 'plan/approve',
							pendingLabel: __( 'Running execute phase...', 'pressark' ),
							successMessage: __( 'Execution started. Review the response below.', 'pressark' ),
							failureMessage: __( 'Failed to start execution.', 'pressark' )
						}
					);
				}

				var reader = response.body.getReader();
				if (self._activeRequest) self._activeRequest.reader = reader;
				var decoder = new TextDecoder();
				var sseBuffer = '';

				function ensureBubble() {
					if (!bubble) {
						self.removeTypingIndicator();
						bubble = self.createStreamingBubble();
						self._streamGotContent = true;
					}
					return bubble;
				}

				function pump() {
					return reader.read().then(function (result) {
						if (result.done) {
							ensureBubble();
							self.finalizeStream(bubble, textBuffer);
							self.setPlanActionState(card, 'error', __( 'Execution stream ended early. Please review the message below.', 'pressark' ), false);
							return { success: false, message: __( 'Execution stream ended early.', 'pressark' ) };
						}

						sseBuffer += decoder.decode(result.value, { stream: true });
						var parsed = self.parseSSEBuffer(sseBuffer);
						sseBuffer = parsed.remaining;

						for (var i = 0; i < parsed.events.length; i++) {
							var evt = parsed.events[i];
							if (evt.type === 'token' || evt.type === 'plan' || evt.type === 'step' || evt.type === 'tool_call' || evt.type === 'tool_progress' || evt.type === 'tool_result' || evt.type === 'done' || evt.type === 'error') {
								ensureBubble();
							}

							try {
								self.handleStreamEvent(evt, bubble);
							} catch (eventErr) {
								self.setPlanActionState(card, 'error', eventErr.message || __( 'Execution failed.', 'pressark' ), false);
								throw eventErr;
							}

							if (evt.type === 'token' && evt.data && evt.data.text) {
								textBuffer += evt.data.text;
							}
							if (evt.type === 'done') {
								self.setPlanActionState(card, 'success', __( 'Execution continued below.', 'pressark' ), true);
								return evt.data || { success: true };
							}
							if (evt.type === 'error') {
								self.setPlanActionState(card, 'error', (evt.data && evt.data.message) || __( 'Execution failed.', 'pressark' ), false);
								throw new Error((evt.data && evt.data.message) || __( 'Execution failed.', 'pressark' ));
							}
						}

						return pump();
					});
				}

				return pump();
			}).catch(function (err) {
				self.finishRequest();

				if (err && err.name === 'AbortError') {
					self.setPlanActionState(card, 'error', __( 'Execution stopped.', 'pressark' ), false);
					return { success: false, message: __( 'Execution stopped.', 'pressark' ) };
				}

				self.setPlanActionState(card, 'error', __( 'Network error. Please try again.', 'pressark' ), false);
				if (bubble) {
					self.renderInterruptedStream(
						bubble,
						__( 'Couldn\'t reach PressArk. Check your connection and try again.', 'pressark' )
					);
				} else {
					self.appendRetryableError(__( 'Couldn\'t reach PressArk. Check your connection and try again.', 'pressark' ));
				}
				return { success: false, message: __( 'Network error. Please try again.', 'pressark' ) };
			});
		},

		revisePlan: function (runId, card, reviseEndpoint) {
			var note = this.getPlanRevisionNote(card);
			if (!note) {
				this.setPlanActionState(card, 'error', __( 'Add a revision note first.', 'pressark' ), false);
				return Promise.resolve({ success: false, message: __( 'Add a revision note first.', 'pressark' ) });
			}

			return this.performPlanAction(
				runId,
				reviseEndpoint,
				{ revision_note: note },
				card,
				{
					path: 'plan/revise',
					pendingLabel: __( 'Revising plan...', 'pressark' ),
					successMessage: __( 'Updated plan requested. Review the response below.', 'pressark' ),
					failureMessage: __( 'Failed to revise the plan.', 'pressark' )
				}
			);
		},

		rejectPlan: function (runId, card, rejectEndpoint) {
			var note = this.getPlanRevisionNote(card);
			var payload = note ? { reason: note } : {};

			return this.performPlanAction(
				runId,
				rejectEndpoint,
				payload,
				card,
				{
					path: 'plan/reject',
					pendingLabel: __( 'Cancelling plan...', 'pressark' ),
					successMessage: __( 'Plan cancelled.', 'pressark' ),
					failureMessage: __( 'Failed to cancel the plan.', 'pressark' )
				}
			);
		},

		escapeHtml: function (text) {
			return String(text)
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&#39;');
		},

		formatPreviewValue: function (value) {
			if (value === null || typeof value === 'undefined') {
				return __( '(empty)', 'pressark' );
			}

			if (typeof value === 'string') {
				return value === '' ? __( '(empty)', 'pressark' ) : value;
			}

			if (typeof value === 'number' || typeof value === 'boolean') {
				return String(value);
			}

			try {
				var json = JSON.stringify(value);
				return json ? json : __( '(empty)', 'pressark' );
			} catch (e) {
				return __( '[unrenderable value]', 'pressark' );
			}
		},

		addActionResult: function (result) {
			var msgEl = document.createElement('div');
			msgEl.dataset.timestamp = String(Date.now());

			if (result.upgrade_prompt) {
				msgEl.className = 'pressark-upgrade-prompt';
				var upgradeUrl = window.pressarkData.upgradeUrl || '#';
				msgEl.innerHTML =
					'<strong>' + this.escapeHtml(__( 'Credit or runtime limit reached', 'pressark' )) + '</strong>' +
					'<p>' + this.escapeHtml(__( 'Local plugin tools are available without a plan gate. Remote AI runs need available credits or runtime capacity.', 'pressark' )) + '</p>' +
					'<a href="' + this.escapeHtml(upgradeUrl) + '" target="_blank" class="pressark-upgrade-btn">' + this.escapeHtml(__( 'Manage billing', 'pressark' )) + '</a>';
				this.messagesEl.appendChild(msgEl);
				this.scrollToBottom();
				return;
			}

			msgEl.className = result.success
				? 'pressark-action-result pressark-action-success'
				: 'pressark-action-result pressark-action-fail';
			var icon = result.success ? pwIcon('check') : pwIcon('x');

			var contentHtml = '<span>' + icon + ' ' + this.escapeHtml(result.message) + '</span>';

			if (result.success && result.log_id) {
				contentHtml += '<button class="pressark-undo-btn" data-log-id="' + result.log_id + '">' + this.escapeHtml(__( 'Undo', 'pressark' )) + '</button>';
			}

			msgEl.innerHTML = contentHtml;

			// Show download link for reports.
			if (result.data && result.data.download_url) {
				var downloadBtn = document.createElement('a');
				downloadBtn.href = result.data.download_url;
				downloadBtn.target = '_blank';
				downloadBtn.className = 'pressark-download-btn';
				downloadBtn.innerHTML = pwIcon('fileDown') + ' ' + this.escapeHtml(__( 'Download Report', 'pressark' ));
				downloadBtn.download = result.data.filename || 'report.html';
				msgEl.appendChild(downloadBtn);
			}

			this.messagesEl.appendChild(msgEl);
			this.scrollToBottom();

			if (result.log_id) {
				this.bindUndoButton(msgEl.querySelector('.pressark-undo-btn'));
			}
		},

		// ── Preview Card Rendering ────────────────────────────────────

		renderPreviewCard: function (pendingAction, runId, actionIndex) {
			var self = this;
			var preview = pendingAction.preview;
			var action = pendingAction.action;
			var riskReceipt = pendingAction.risk_receipt || null;
			var validationError = pendingAction.validation_error || (preview && preview.validation_error) || '';
			var canApply = !validationError && pendingAction.status !== 'invalid_input';

			// Store action in JS-side map instead of HTML attribute (A13: prevents XSS).
			var actionId = 'action_' + (++this.actionIdCounter);
			this.pendingActions[actionId] = action;
			this.pendingPreviews[actionId] = preview;
			this.pendingActionIndices[actionId] = (typeof actionIndex !== 'undefined') ? actionIndex : 0;
			// v3.1.0: Associate run_id so /confirm can resume the durable run.
			if (runId) {
				this.pendingRunIds[actionId] = runId;
			}

			var card = document.createElement('div');
			card.className = 'pressark-preview-card';

			var changesHTML = '';
			if (preview.changes && preview.changes.length > 0) {
				for (var i = 0; i < preview.changes.length; i++) {
					var change = preview.changes[i];
					var beforeValue = this.formatPreviewValue(change.before);
					var afterValue = this.formatPreviewValue(change.after);
					changesHTML +=
						'<div class="pressark-preview-change">' +
						'<div class="pressark-preview-field">' + this.escapeHtml(change.field) + '</div>' +
						'<div class="pressark-preview-before">' +
						'<span class="pressark-preview-label">' + this.escapeHtml(__( 'Before:', 'pressark' )) + ' </span>' +
						'<span class="pressark-preview-value">' + this.escapeHtml(beforeValue) + '</span>' +
						'</div>' +
						'<div class="pressark-preview-after">' +
						'<span class="pressark-preview-label">' + this.escapeHtml(__( 'After:', 'pressark' )) + ' </span>' +
						'<span class="pressark-preview-value">' + this.escapeHtml(afterValue) + '</span>' +
						'</div>' +
						'</div>';
				}
			}

			var warningsHTML = '';
			if (preview.seo_warnings && preview.seo_warnings.length > 0) {
				warningsHTML = '<div class="pressark-seo-warnings">';
				for (var w = 0; w < preview.seo_warnings.length; w++) {
					var warn = preview.seo_warnings[w];
					var warnClass = 'pressark-seo-warn--' + (warn.type || 'info');
					var warnIcon = warn.type === 'warning' ? pwIcons.warning
						: warn.type === 'caution' ? pwIcons.warning
						: pwIcons.info;
					warningsHTML +=
						'<div class="pressark-seo-warn ' + warnClass + '">' +
						'<span class="pressark-seo-warn-icon">' + warnIcon + '</span>' +
						'<span class="pressark-seo-warn-label">' + this.escapeHtml(warn.label) + '</span>' +
						'<span class="pressark-seo-warn-detail">' + this.escapeHtml(warn.detail) + '</span>' +
						'</div>';
				}
				warningsHTML += '</div>';
			}

			var title = '';
			if (preview.post_title) {
				/* translators: %s: post title. */
				title = sprintf( this.escapeHtml(__( 'Proposed changes to "%s"', 'pressark' )), this.escapeHtml(preview.post_title) );
			} else {
				title = this.escapeHtml(__( 'Proposed changes', 'pressark' ));
			}
			var riskHtml = this.renderRiskReceipt(riskReceipt);
			var validationHtml = validationError
				? '<div class="pressark-action-result pressark-action-fail"><span>' + pwIcon('x') + ' ' + this.escapeHtml(validationError) + '</span></div>'
				: '';
			var actionsHtml = canApply
				? '<button type="button" class="pressark-preview-confirm">' +
					this.getPreviewButtonContent(pwIcons.check, __( 'Approve & apply', 'pressark' )) +
					'</button>' +
					'<button type="button" class="pressark-preview-cancel">' +
					this.getPreviewButtonContent(pwIcons.x, __( 'Decline', 'pressark' )) +
					'</button>'
				: '<button type="button" class="pressark-preview-cancel">' +
					this.getPreviewButtonContent(pwIcons.x, __( 'Dismiss', 'pressark' )) +
					'</button>';

			card.innerHTML =
				'<div class="pressark-preview-header">' +
				this.getPreviewDocumentIconMarkup() +
				'<span class="pressark-preview-title">' + title + '</span>' +
				'</div>' +
				'<div class="pressark-preview-changes">' + changesHTML + '</div>' +
				warningsHTML +
				riskHtml +
				validationHtml +
				'<div class="pressark-preview-actions">' +
				actionsHtml +
				'</div>';

			var previewConfirmBtn = card.querySelector('.pressark-preview-confirm');
			if (previewConfirmBtn) {
				previewConfirmBtn.addEventListener('click', function (e) {
					var btn = e.currentTarget;
					var actionData = self.pendingActions[actionId];
					var actionRunId = self.pendingRunIds[actionId] || '';
					var actionPendingIndex = self.pendingActionIndices[actionId] || 0;
					btn.textContent = __( 'Applying...', 'pressark' );
					btn.disabled = true;
					card.querySelector('.pressark-preview-cancel').disabled = true;

					self.confirmAction(actionData, true, actionRunId, actionPendingIndex, card).then(function (result) {
						var previewData = self.pendingPreviews[actionId];
						self.renderConfirmResult(card, result, previewData);
						delete self.pendingActions[actionId];
						delete self.pendingPreviews[actionId];
						delete self.pendingRunIds[actionId];
						delete self.pendingActionIndices[actionId];

						if (result && result.checkpoint && typeof result.checkpoint === 'object') {
							self.checkpoint = result.checkpoint;
						}

						// v3.7.3: Auto-resume with enriched continuation context.
						// Uses [Continue] prefix so server-side classify_task detects
						// this is a continuation and classifies based on the ORIGINAL
						// user request (from conversation history), selecting the right
						// model tier and domain skills for remaining steps.
						if (result && result.success && !result.cancelled
							&& (!self.getApprovalOutcomeStatus(result) || self.getApprovalOutcomeStatus(result) === 'approved')
							&& self.shouldAutoResume(result)
							&& Object.keys(self.pendingActions).length === 0) {
							setTimeout(function () {
								self.sendMessage(self.buildContinuationMessage(result, result.message || 'Action applied.'));
							}, 600);
						} else if (result && result.success && result.continuation && result.continuation.pause_message) {
							self.addMessage('ai', result.continuation.pause_message);
							self.conversation.push({ role: 'assistant', content: result.continuation.pause_message });
						}
					});
				});
			}

			card.querySelector('.pressark-preview-cancel').addEventListener('click', function () {
				var cancelBtn = card.querySelector('.pressark-preview-cancel');
				var confirmBtn = card.querySelector('.pressark-preview-confirm');
				var actionData = self.pendingActions[actionId];
				var actionRunId = self.pendingRunIds[actionId] || '';
				var actionPendingIndex = self.pendingActionIndices[actionId] || 0;
				var previewData = self.pendingPreviews[actionId];
				if (cancelBtn) {
					cancelBtn.textContent = __( 'Declining...', 'pressark' );
					cancelBtn.disabled = true;
				}
				if (confirmBtn) {
					confirmBtn.disabled = true;
				}
				self.confirmAction(actionData, false, actionRunId, actionPendingIndex, card).then(function (result) {
					self.renderConfirmResult(card, result, previewData);
					delete self.pendingActions[actionId];
					delete self.pendingPreviews[actionId];
					delete self.pendingRunIds[actionId];
					delete self.pendingActionIndices[actionId];

					if (result && result.checkpoint && typeof result.checkpoint === 'object') {
						self.checkpoint = result.checkpoint;
					}
				});
			});

			this.messagesEl.appendChild(card);
			this.scrollToBottom();
		},

		/**
		 * Build a serialisable card summary for conversation history.
		 * Format: [PRESSARK_CARD:<status>]<title>||<field:before→after>||...
		 */
		buildCardSummary: function (preview, status) {
			var title = '';
			if (preview.post_title) {
				/* translators: %s: post title. */
				title = sprintf( __( 'Proposed changes to "%s"', 'pressark' ), preview.post_title );
			} else {
				title = __( 'Proposed changes', 'pressark' );
			}
			var parts = [title];
			if (preview.changes && preview.changes.length > 0) {
				for (var i = 0; i < preview.changes.length; i++) {
					var c = preview.changes[i];
					parts.push((c.field || '') + ': ' + this.formatPreviewValue(c.before) + ' \u2192 ' + this.formatPreviewValue(c.after));
				}
			}
			return '[PRESSARK_CARD:' + status + ']' + parts.join('||');
		},

		getApprovalOutcomeStatus: function (result) {
			if (!result || typeof result !== 'object') return '';
			if (result.approval_receipt && typeof result.approval_receipt.status === 'string') {
				return result.approval_receipt.status;
			}
			if (result.approval_outcome && typeof result.approval_outcome.status === 'string') {
				return result.approval_outcome.status;
			}
			if (result.discarded) return 'discarded';
			if (result.cancelled) return 'cancelled';
			if (result.success) return 'approved';
			return '';
		},

		getApprovalReceipt: function (result) {
			if (!result || typeof result !== 'object') return null;
			if (!result.approval_receipt || typeof result.approval_receipt !== 'object') return null;
			return result.approval_receipt;
		},

		getApprovalSettlement: function (result) {
			var receipt = this.getApprovalReceipt(result);
			if (receipt) {
				return {
					status: typeof receipt.status === 'string' ? receipt.status : '',
					acknowledged: receipt.acknowledged === true,
					settled: receipt.settled === true,
					receipt: receipt
				};
			}

			var status = this.getApprovalOutcomeStatus(result);
			return {
				status: status,
				acknowledged: !!status,
				settled: !!status,
				receipt: null
			};
		},

		renderRiskReceipt: function (riskReceipt) {
			if (!riskReceipt || typeof riskReceipt !== 'object') return '';

			var rows = [];
			if (riskReceipt.target) {
				rows.push('<div class="pressark-risk-receipt__row"><span class="pressark-risk-receipt__label">' + this.escapeHtml(__( 'Target', 'pressark' )) + '</span><span class="pressark-risk-receipt__value">' + this.escapeHtml(riskReceipt.target) + '</span></div>');
			}
			if (riskReceipt.blast_radius) {
				rows.push('<div class="pressark-risk-receipt__row"><span class="pressark-risk-receipt__label">' + this.escapeHtml(__( 'Blast radius', 'pressark' )) + '</span><span class="pressark-risk-receipt__value">' + this.escapeHtml(riskReceipt.blast_radius) + '</span></div>');
			}
			if (riskReceipt.reversibility) {
				rows.push('<div class="pressark-risk-receipt__row"><span class="pressark-risk-receipt__label">' + this.escapeHtml(__( 'Reversibility', 'pressark' )) + '</span><span class="pressark-risk-receipt__value">' + this.escapeHtml(riskReceipt.reversibility) + '</span></div>');
			}

			var effectsHtml = '';
			if (Array.isArray(riskReceipt.downstream_effects) && riskReceipt.downstream_effects.length > 0) {
				var effects = [];
				for (var i = 0; i < riskReceipt.downstream_effects.length; i++) {
					effects.push('<li>' + this.escapeHtml(riskReceipt.downstream_effects[i]) + '</li>');
				}
				effectsHtml = '<ul class="pressark-risk-receipt__effects">' + effects.join('') + '</ul>';
			}

			var verificationHtml = riskReceipt.verification_plan
				? '<div class="pressark-risk-receipt__verification"><span class="pressark-risk-receipt__label">' + this.escapeHtml(__( 'Verification', 'pressark' )) + '</span><span class="pressark-risk-receipt__value">' + this.escapeHtml(riskReceipt.verification_plan) + '</span></div>'
				: '';

			var badges = [];
			if (riskReceipt.risk_level) {
				badges.push('<span class="pressark-risk-badge pressark-risk-badge--' + this.escapeHtml(riskReceipt.risk_level) + '">' + this.escapeHtml(riskReceipt.risk_level) + '</span>');
			}
			if (riskReceipt.approval_mode) {
				badges.push('<span class="pressark-risk-badge">' + this.escapeHtml(riskReceipt.approval_mode) + '</span>');
			}

			return '<div class="pressark-risk-receipt">' +
				'<div class="pressark-risk-receipt__header">' +
				'<span class="pressark-risk-receipt__title">' + pwIcon('shield') + '<span>' + this.escapeHtml(riskReceipt.label || __( 'Change review', 'pressark' )) + '</span></span>' +
				(badges.length ? '<span class="pressark-risk-receipt__badges">' + badges.join('') + '</span>' : '') +
				'</div>' +
				(rows.length ? '<div class="pressark-risk-receipt__grid">' + rows.join('') + '</div>' : '') +
				effectsHtml +
				verificationHtml +
				'</div>';
		},

		renderRunSurface: function (runSurface) {
			if (!runSurface || typeof runSurface !== 'object') return '';

			var summary = runSurface.summary || runSurface.route_label || __( 'Run details', 'pressark' );
			var badges = [];
			if (Array.isArray(runSurface.badges)) {
				for (var i = 0; i < runSurface.badges.length; i++) {
					var badge = runSurface.badges[i];
					if (!badge || !badge.label) continue;
					var tone = badge.tone || 'neutral';
					badges.push('<span class="pressark-run-surface__badge pressark-run-surface__badge--' + this.escapeHtml(tone) + '">' + this.escapeHtml(badge.label) + '</span>');
				}
			}

			var metricChips = [];
			if (Array.isArray(runSurface.metric_chips)) {
				for (var m = 0; m < runSurface.metric_chips.length; m++) {
					var chip = runSurface.metric_chips[m];
					if (!chip || !chip.label || !chip.value) continue;
					var chipTone = chip.tone || 'neutral';
					metricChips.push(
						'<div class="pressark-run-surface__metric pressark-run-surface__metric--' + this.escapeHtml(chipTone) + '">' +
							'<span class="pressark-run-surface__metric-label">' + this.escapeHtml(chip.label) + '</span>' +
							'<span class="pressark-run-surface__metric-value">' + this.escapeHtml(chip.value) + '</span>' +
						'</div>'
					);
				}
			}

			var notices = [];
			if (Array.isArray(runSurface.notices)) {
				for (var n = 0; n < runSurface.notices.length; n++) {
					var notice = runSurface.notices[n];
					if (!notice || (!notice.label && !notice.text)) continue;
					var noticeTone = notice.tone || 'neutral';
					var noticeIcon = noticeTone === 'warning' ? pwIcon('warning') : pwIcon('info');
					var noticeMeta = notice.meta
						? '<span class="pressark-run-surface__notice-meta">' + this.escapeHtml(notice.meta) + '</span>'
						: '';
					var noticeText = notice.text
						? '<div class="pressark-run-surface__notice-text">' + this.escapeHtml(notice.text) + '</div>'
						: '';
					var noticeHint = notice.hint
						? '<div class="pressark-run-surface__notice-hint">' + this.escapeHtml(notice.hint) + '</div>'
						: '';

					notices.push(
						'<div class="pressark-run-surface__notice pressark-run-surface__notice--' + this.escapeHtml(noticeTone) + '">' +
							'<div class="pressark-run-surface__notice-top">' +
								'<span class="pressark-run-surface__notice-title">' + noticeIcon + '<span>' + this.escapeHtml(notice.label || __( 'Run note', 'pressark' )) + '</span></span>' +
								noticeMeta +
							'</div>' +
							noticeText +
							noticeHint +
						'</div>'
					);
				}
			}

			var rows = [];
			if (Array.isArray(runSurface.detail_rows)) {
				for (var j = 0; j < runSurface.detail_rows.length; j++) {
					var row = runSurface.detail_rows[j];
					if (!row || !row.label || !row.value) continue;
					rows.push('<div class="pressark-run-surface__row"><span class="pressark-run-surface__label">' + this.escapeHtml(row.label) + '</span><span class="pressark-run-surface__value">' + this.escapeHtml(row.value) + '</span></div>');
				}
			}

			var receiptHtml = this.renderRunBillingReceipt(runSurface.billing_receipt);
			var bodyHtml = '';
			if (metricChips.length) {
				bodyHtml += '<div class="pressark-run-surface__metrics">' + metricChips.join('') + '</div>';
			}
			if (notices.length) {
				bodyHtml += '<div class="pressark-run-surface__notices">' + notices.join('') + '</div>';
			}
			if (rows.length) {
				bodyHtml += '<div class="pressark-run-surface__rows">' + rows.join('') + '</div>';
			}
			if (receiptHtml) {
				bodyHtml += receiptHtml;
			}

			return '<details class="pressark-run-surface">' +
				'<summary class="pressark-run-surface__summary">' +
				'<span class="pressark-run-surface__summary-main">' + pwIcon('sparkles') + '<span class="pressark-run-surface__summary-text">' + this.escapeHtml(summary) + '</span></span>' +
				(badges.length ? '<span class="pressark-run-surface__badges">' + badges.join('') + '</span>' : '') +
				'</summary>' +
				(bodyHtml ? '<div class="pressark-run-surface__body">' + bodyHtml + '</div>' : '') +
				'</details>';
		},

		renderRunBillingReceipt: function (receipt) {
			if (!receipt || typeof receipt !== 'object') return '';

			var headerBadges = [];
			if (receipt.authority_label) {
				headerBadges.push('<span class="pressark-run-receipt__badge">' + this.escapeHtml(receipt.authority_label) + '</span>');
			}
			if (receipt.service_label) {
				headerBadges.push('<span class="pressark-run-receipt__badge">' + this.escapeHtml(receipt.service_label) + '</span>');
			}
			if (receipt.spend_label) {
				headerBadges.push('<span class="pressark-run-receipt__badge">' + this.escapeHtml(receipt.spend_label) + '</span>');
			}

			var stages = [];
			if (Array.isArray(receipt.stages)) {
				for (var i = 0; i < receipt.stages.length; i++) {
					var stage = receipt.stages[i];
					if (!stage || !stage.label || !stage.value) continue;
					var tone = stage.tone || 'neutral';
					var secondary = stage.secondary
						? '<div class="pressark-run-receipt__stage-secondary">' + this.escapeHtml(stage.secondary) + '</div>'
						: '';
					var note = stage.note
						? '<div class="pressark-run-receipt__stage-note">' + this.escapeHtml(stage.note) + '</div>'
						: '';
					var authority = stage.authority_tag
						? '<span class="pressark-run-receipt__stage-authority">' + this.escapeHtml(stage.authority_tag) + '</span>'
						: '';

					stages.push(
						'<div class="pressark-run-receipt__stage pressark-run-receipt__stage--' + this.escapeHtml(tone) + '">' +
							'<div class="pressark-run-receipt__stage-top">' +
								'<span class="pressark-run-receipt__stage-label">' + this.escapeHtml(stage.label) + '</span>' +
								authority +
							'</div>' +
							'<div class="pressark-run-receipt__stage-value">' + this.escapeHtml(stage.value) + '</div>' +
							secondary +
							note +
						'</div>'
					);
				}
			}

			var reducedHtml = '';
			if (receipt.reduced_certainty && receipt.reduced_certainty.label) {
				reducedHtml =
					'<div class="pressark-run-receipt__degraded">' +
						'<span class="pressark-run-receipt__degraded-label">' + this.escapeHtml(receipt.reduced_certainty.label) + '</span>' +
						(receipt.reduced_certainty.value ? '<span class="pressark-run-receipt__degraded-value">' + this.escapeHtml(receipt.reduced_certainty.value) + '</span>' : '') +
						(receipt.reduced_certainty.detail ? '<div class="pressark-run-receipt__degraded-note">' + this.escapeHtml(receipt.reduced_certainty.detail) + '</div>' : '') +
					'</div>';
			}

			var notices = [];
			if (Array.isArray(receipt.notices)) {
				for (var j = 0; j < receipt.notices.length; j++) {
					var notice = receipt.notices[j];
					if (!notice || !notice.label || !notice.text) continue;
					var noticeTone = notice.tone || 'neutral';
					notices.push(
						'<div class="pressark-run-receipt__notice pressark-run-receipt__notice--' + this.escapeHtml(noticeTone) + '">' +
							'<span class="pressark-run-receipt__notice-label">' + this.escapeHtml(notice.label) + '</span>' +
							'<span class="pressark-run-receipt__notice-text">' + this.escapeHtml(notice.text) + '</span>' +
						'</div>'
					);
				}
			}

			return '<section class="pressark-run-receipt">' +
				'<div class="pressark-run-receipt__header">' +
					'<div class="pressark-run-receipt__title-wrap">' +
						'<span class="pressark-run-receipt__title">' + this.escapeHtml(receipt.label || __( 'Per-run receipt', 'pressark' )) + '</span>' +
						(receipt.summary ? '<span class="pressark-run-receipt__summary">' + this.escapeHtml(receipt.summary) + '</span>' : '') +
					'</div>' +
					(headerBadges.length ? '<div class="pressark-run-receipt__badges">' + headerBadges.join('') + '</div>' : '') +
				'</div>' +
				reducedHtml +
				(stages.length ? '<div class="pressark-run-receipt__stages">' + stages.join('') + '</div>' : '') +
				(notices.length ? '<div class="pressark-run-receipt__notices">' + notices.join('') + '</div>' : '') +
			'</section>';
		},

		decorateAssistantMessage: function () {
			// Run-surface diagnostics (route / transport / model rows) intentionally hidden from chat UI.
		},

		getPreviewDocumentIconMarkup: function () {
			return '<span class="pressark-preview-icon" aria-hidden="true">' +
				'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
				'<path d="M8 3.75h6l4 4v12.5a.75.75 0 0 1-.75.75H8a2.25 2.25 0 0 1-2.25-2.25V6A2.25 2.25 0 0 1 8 3.75Z"></path>' +
				'<path d="M14 3.75V8h4"></path>' +
				'<path d="M9 12h6"></path>' +
				'<path d="M9 15.5h6"></path>' +
				'</svg>' +
				'</span>';
		},

		getPreviewButtonContent: function (iconMarkup, label) {
			return '<span class="pressark-btn__icon" aria-hidden="true">' + iconMarkup + '</span>' +
				'<span class="pressark-btn__label">' + this.escapeHtml(label) + '</span>';
		},

		setPreviewFooterBusy: function (footerEl, isBusy, action) {
			if (!footerEl) return;

			var keepBtn = footerEl.querySelector('.pressark-btn--keep');
			var discardBtn = footerEl.querySelector('.pressark-btn--discard');

			if (keepBtn) {
				keepBtn.disabled = !!isBusy;
				keepBtn.setAttribute('aria-busy', isBusy && action === 'keep' ? 'true' : 'false');
				keepBtn.innerHTML = this.getPreviewButtonContent(pwIcons.check, isBusy && action === 'keep' ? __( 'Applying...', 'pressark' ) : __( 'Keep Changes', 'pressark' ));
			}

			if (discardBtn) {
				discardBtn.disabled = !!isBusy;
				discardBtn.setAttribute('aria-busy', isBusy && action === 'discard' ? 'true' : 'false');
				discardBtn.innerHTML = this.getPreviewButtonContent(pwIcons.x, isBusy && action === 'discard' ? __( 'Discarding...', 'pressark' ) : __( 'Discard', 'pressark' ));
			}
		},

		setPreviewFooterSettled: function (status) {
			if (!this.activePreviewFooterEl) return;

			var normalized = status || '';
			var isApproved = normalized === 'approved' || normalized === 'keep';
			var statusClass = isApproved
				? 'pressark-preview-footer__status--keep'
				: 'pressark-preview-footer__status--discard';
			var label = isApproved ? __( 'Preview approved', 'pressark' ) : __( 'Preview discarded', 'pressark' );
			var icon = isApproved ? pwIcons.check : pwIcons.x;

			this.activePreviewFooterEl.classList.add('pressark-preview-footer--settled');
			this.activePreviewFooterEl.innerHTML =
				'<div class="pressark-preview-footer__status ' + statusClass + '">' +
				this.getPreviewButtonContent(icon, label) +
				'</div>';
			this.activePreviewFooterEl = null;
		},

		/**
		 * Render a static (non-interactive) card from a history summary string.
		 */
		renderStaticCard: function (content) {
			var match = content.match(/^\[PRESSARK_CARD:(applied|cancelled|declined|discarded)\](.*)/);
			if (!match) return null;

			var status = match[1];
			var payload = match[2];
			var parts = payload.split('||');
			var title = parts[0] || __( 'Proposed changes', 'pressark' );

			var card = document.createElement('div');
			card.className = 'pressark-preview-card ' +
				(status === 'applied' ? 'pressark-preview-applied' : 'pressark-preview-dismissed');

			var changesHTML = '';
			for (var i = 1; i < parts.length; i++) {
				var fieldMatch = parts[i].match(/^(.+?): (.+?) \u2192 (.+)$/);
				if (fieldMatch) {
					changesHTML +=
						'<div class="pressark-preview-change">' +
						'<div class="pressark-preview-field">' + this.escapeHtml(fieldMatch[1]) + '</div>' +
						'<div class="pressark-preview-before">' +
						'<span class="pressark-preview-label">' + this.escapeHtml(__( 'Before:', 'pressark' )) + ' </span>' +
						'<span class="pressark-preview-value">' + this.escapeHtml(fieldMatch[2]) + '</span>' +
						'</div>' +
						'<div class="pressark-preview-after">' +
						'<span class="pressark-preview-label">' + this.escapeHtml(__( 'After:', 'pressark' )) + ' </span>' +
						'<span class="pressark-preview-value">' + this.escapeHtml(fieldMatch[3]) + '</span>' +
						'</div>' +
						'</div>';
				}
			}

			var resultHTML = status === 'applied'
				? '<div class="pressark-action-result pressark-action-success"><span>' + pwIcon('check') + ' ' + this.escapeHtml(__( 'Changes applied successfully', 'pressark' )) + '</span></div>'
				: status === 'declined'
					? '<div class="pressark-preview-cancelled"><span>' + pwIcon('x') + ' ' + this.escapeHtml(__( 'Confirmation declined', 'pressark' )) + '</span></div>'
					: status === 'discarded'
						? '<div class="pressark-preview-cancelled"><span>' + pwIcon('x') + ' ' + this.escapeHtml(__( 'Preview discarded', 'pressark' )) + '</span></div>'
						: '<div class="pressark-preview-cancelled"><span>' + pwIcon('x') + ' ' + this.escapeHtml(__( 'Changes cancelled', 'pressark' )) + '</span></div>';

			card.innerHTML =
				'<div class="pressark-preview-header">' +
				this.getPreviewDocumentIconMarkup() +
				'<span class="pressark-preview-title">' + this.escapeHtml(title) + '</span>' +
				'</div>' +
				'<div class="pressark-preview-changes">' + changesHTML + '</div>' +
				'<div class="pressark-preview-actions">' + resultHTML + '</div>';

			return card;
		},

		confirmAction: function (actionData, confirmed, runId, actionIndex, card) {
			if (confirmed && window.pressarkData && window.pressarkData.streamingEnabled !== false) {
				return this.confirmActionStream(runId, actionIndex, card);
			}

			var data = window.pressarkData;
			var payload = {
				confirmed: confirmed,
				run_id: runId || '',
				action_index: (typeof actionIndex !== 'undefined') ? actionIndex : 0
			};
			return fetch(data.restUrl + 'confirm', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce
				},
				body: JSON.stringify(payload)
			})
				.then(function (response) { return response.json(); })
				.catch(function () {
					return { success: false, message: __( 'Network error. Please try again.', 'pressark' ) };
				});
		},

		beginPassiveRequest: function () {
			this._confirmStreamActive = true;
			this._toolProgressState = {};
			if (this.sendBtn) {
				this.sendBtn.disabled = true;
			}
			if (this.inputEl) {
				this.inputEl.disabled = true;
			}
		},

		finishPassiveRequest: function () {
			this._confirmStreamActive = false;
			this._toolProgressState = {};
			if (this.sendBtn) {
				this.sendBtn.disabled = false;
			}
			if (this.inputEl) {
				this.inputEl.disabled = false;
			}
		},

		buildConfirmStreamSurface: function (card) {
			if (!card) return null;

			var actionsDiv = card.querySelector('.pressark-preview-actions');
			if (!actionsDiv) return null;

			actionsDiv.innerHTML =
				'<div class="pressark-confirm-stream">' +
				'<div class="pressark-confirm-stream__label">' + this.escapeHtml(__( 'Applying changes...', 'pressark' )) + '</div>' +
				'<div class="pressark-confirm-stream__body"></div>' +
				'</div>';

			return actionsDiv.querySelector('.pressark-confirm-stream__body');
		},

		handleConfirmStreamEvent: function (event, contentEl) {
			if (!contentEl || !event) return null;

			switch (event.type) {
				case 'step':
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, event.data);
					return null;

				case 'tool_call':
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'reading',
						label: event.data && event.data.name ? event.data.name.replace(/_/g, ' ') : __( 'Processing', 'pressark' ),
						tool: (event.data && (event.data.name || event.data.tool)) || '',
						toolKey: this.getToolProgressKey(event.data),
					});
					return null;

				case 'tool_progress':
					var progressData = (event.data && typeof event.data.progress === 'object' && event.data.progress)
						? event.data.progress
						: {};
					var progressKey = this.getToolProgressKey(event.data);
					if (!this._acceptToolProgressEvent(progressKey, event.data && event.data.sequence)) {
						return null;
					}

					var processed = parseInt(progressData.processed, 10);
					var total = parseInt(progressData.total, 10);
					var percent = (!isNaN(processed) && !isNaN(total) && total > 0)
						? Math.round((processed / total) * 100)
						: null;
					var toolName = (event.data && (event.data.name || event.data.tool)) || __( 'Processing', 'pressark' );
					var progressLabel = toolName.replace(/_/g, ' ');
					if (!isNaN(processed) && !isNaN(total) && total > 0) {
						progressLabel += ' ' + processed + '/' + total;
					}

					var detailParts = [];
					if (typeof progressData.message === 'string' && progressData.message) {
						detailParts.push(progressData.message);
					}
					if (!isNaN(progressData.updated)) {
						/* translators: %d: number of updated items. */
						detailParts.push(sprintf( __( '%d updated', 'pressark' ), progressData.updated ));
					}
					if (!isNaN(progressData.errors) && progressData.errors > 0) {
						/* translators: %d: number of errors. */
						detailParts.push(sprintf( _n( '%d error', '%d errors', progressData.errors, 'pressark' ), progressData.errors ));
					}

					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'reading',
						label: progressLabel,
						tool: event.data ? (event.data.name || event.data.tool || '') : '',
						toolKey: progressKey,
						detail: detailParts.join(' · '),
						progressPercent: percent,
						progressValue: !isNaN(processed) ? processed : null,
						progressMax: !isNaN(total) ? total : null,
						progressText: (!isNaN(processed) && !isNaN(total) && total > 0) ? (processed + '/' + total) : ''
					});
					return null;

				case 'tool_result':
					var doneKey = this.getToolProgressKey(event.data);
					var doneName = ((event.data && event.data.name) || '').replace(/_/g, ' ');
					if (doneKey && this._toolProgressState) {
						delete this._toolProgressState[doneKey];
					}
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'done',
						/* translators: %s: completed tool or action name. */
						label: doneName ? sprintf( __( '%s complete', 'pressark' ), doneName ) : __( 'Action complete', 'pressark' ),
						tool: (event.data && event.data.name) || '',
						toolKey: doneKey,
						detail: (event.data && event.data.summary) || '',
						progressPercent: 100,
					});
					return null;

				case 'done':
					return event.data || {};

				case 'error':
					throw new Error((event.data && event.data.message) || __( 'Unable to finish applying changes.', 'pressark' ));
			}

			return null;
		},

		confirmActionStream: function (runId, actionIndex, card) {
			var self = this;
			var data = window.pressarkData || {};
			var contentEl = this.buildConfirmStreamSurface(card);
			var payload = {
				confirmed: true,
				run_id: runId || '',
				action_index: (typeof actionIndex !== 'undefined') ? actionIndex : 0
			};

			this.beginPassiveRequest();

			return fetch(data.restUrl + 'confirm-stream', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce
				},
				body: JSON.stringify(payload)
			}).then(function (response) {
				if (!response.ok || !response.body) {
					self.finishPassiveRequest();
					return fetch(data.restUrl + 'confirm', {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
							'X-WP-Nonce': data.nonce
						},
						body: JSON.stringify(payload)
					}).then(function (fallbackResponse) {
						return fallbackResponse.json();
					});
				}

				var reader = response.body.getReader();
				var decoder = new TextDecoder();
				var sseBuffer = '';

				return new Promise(function (resolve, reject) {
					function pump() {
						reader.read().then(function (chunk) {
							if (chunk.done) {
								self.finishPassiveRequest();
								reject(new Error(__( 'PressArk lost the progress stream before the action finished.', 'pressark' )));
								return;
							}

							sseBuffer += decoder.decode(chunk.value, { stream: true });
							var parsed = self.parseSSEBuffer(sseBuffer);
							sseBuffer = parsed.remaining;

							for (var i = 0; i < parsed.events.length; i++) {
								try {
									var maybeResult = self.handleConfirmStreamEvent(parsed.events[i], contentEl);
									if (maybeResult) {
										self.finishPassiveRequest();
										resolve(maybeResult);
										return;
									}
								} catch (eventError) {
									self.finishPassiveRequest();
									reject(eventError);
									return;
								}
							}

							pump();
						}).catch(function (streamError) {
							self.finishPassiveRequest();
							reject(streamError);
						});
					}

					pump();
				});
			}).catch(function () {
				self.finishPassiveRequest();
				return { success: false, message: __( 'Network error. Please try again.', 'pressark' ) };
			});
		},

		renderConfirmResult: function (card, result, previewData) {
			var actionsDiv = card.querySelector('.pressark-preview-actions');
			var outcomeStatus = this.getApprovalOutcomeStatus(result);

			if (result.success && outcomeStatus !== 'declined') {
				var undoHtml = '';
				if (result.log_id) {
					undoHtml = '<button class="pressark-undo-btn" data-log-id="' + result.log_id + '">' + this.escapeHtml(__( 'Undo', 'pressark' )) + '</button>';
				}
				// v3.1.0: Surface post-apply verification summary.
				var verifyHtml = '';
				if (result.verification && result.verification.message) {
					var verifyClass = result.verification.is_error
						? 'pressark-verify-warning' : 'pressark-verify-ok';
					verifyHtml = '<div class="pressark-verification ' + verifyClass + '">' +
						this.escapeHtml(result.verification.message) + '</div>';
				}
				actionsDiv.innerHTML =
					'<div class="pressark-action-result pressark-action-success">' +
					'<span>' + pwIcon('check') + ' ' + this.escapeHtml(result.message || __( 'Changes applied successfully', 'pressark' )) + '</span>' +
					undoHtml +
					'</div>' + verifyHtml;
				card.classList.add('pressark-preview-applied');
				// Save card summary for history rendering.
				var cardContent = previewData
					? this.buildCardSummary(previewData, 'applied')
					: (result.message || __( 'Changes applied successfully.', 'pressark' ));
				this.conversation.push({ role: 'assistant', content: cardContent });
				if (result.usage) {
					this.updateUsage(result.usage);
				}

				var undoBtn = actionsDiv.querySelector('.pressark-undo-btn');
				if (undoBtn) this.bindUndoButton(undoBtn);
			} else if (outcomeStatus === 'declined') {
				actionsDiv.innerHTML =
					'<div class="pressark-preview-cancelled">' +
					'<span>' + pwIcon('x') + ' ' + this.escapeHtml(result.message || __( 'No changes were made.', 'pressark' )) + '</span>' +
					'</div>';
				card.classList.add('pressark-preview-dismissed');
				if (previewData) {
					this.conversation.push({ role: 'assistant', content: this.buildCardSummary(previewData, 'declined') });
				}
			} else if (result.upgrade_prompt) {
				var upgradeUrl = window.pressarkData.upgradeUrl || '#';
				actionsDiv.innerHTML =
					'<div class="pressark-upgrade-prompt">' +
					'<strong>' + this.escapeHtml(__( 'Credit or runtime limit reached', 'pressark' )) + '</strong>' +
					'<p>' + this.escapeHtml(__( 'Local plugin tools are available without a plan gate. Remote AI runs need available credits or runtime capacity.', 'pressark' )) + '</p>' +
					'<a href="' + this.escapeHtml(upgradeUrl) + '" target="_blank" class="pressark-upgrade-btn">' + this.escapeHtml(__( 'Manage billing', 'pressark' )) + '</a>' +
					'</div>';
			} else {
				actionsDiv.innerHTML =
					'<div class="pressark-action-result pressark-action-fail">' +
					'<span>' + pwIcon('x') + ' ' + this.escapeHtml(result.message || __( 'Failed to apply changes', 'pressark' )) + '</span>' +
					'</div>';
			}

			this.autoSaveChat();
		},

		// ── Usage Display Update ──────────────────────────────────────

		buildContinuationMessage: function (result, fallbackSummary) {
			var continuation = (result && result.continuation) ? result.continuation : {};
			var execution = continuation.execution || ((result && result.checkpoint && result.checkpoint.execution) ? result.checkpoint.execution : {});
			var targets = (result && result.targets && result.targets.length)
				? result.targets
				: (continuation.targets || []);
			var primaryTarget = targets.length ? (targets[0] || {}) : {};
			var summary = fallbackSummary || (result && result.message) || 'Action applied.';
			var completed = [];
			var remaining = [];
			var postTitle = '';
			var postId = '';
			var url = '';
			var seoRemainingForTarget = false;
			var shouldEmitWrap = continuation.should_emit_wrap_round === true || continuation.evaluator_should_emit_wrap === true;

			if (result) {
				postTitle = result.post_title || '';
				postId = result.post_id || '';
				url = result.url || '';
			}

			if (!postTitle && continuation.post_title) postTitle = continuation.post_title;
			if (!postId && continuation.post_id) postId = continuation.post_id;
			if (!url && continuation.url) url = continuation.url;

			if (!postTitle && primaryTarget.post_title) postTitle = primaryTarget.post_title;
			if (!postId && primaryTarget.post_id) postId = primaryTarget.post_id;
			if (!url && primaryTarget.url) url = primaryTarget.url;

			if (execution && execution.current_target) {
				if (!postTitle && execution.current_target.post_title) postTitle = execution.current_target.post_title;
				if (!postId && execution.current_target.post_id) postId = execution.current_target.post_id;
				if (!url && execution.current_target.url) url = execution.current_target.url;
			}

			if (execution && execution.tasks && execution.tasks.length) {
				// v5.6.4 (2026-05-12): `verified` is the strongest completion state
				// — PressArk_Verification upgrades `completed` → `verified` after
				// a successful read-back evidence check. Without including it
				// here, verified tasks falsely land in `remaining[]` and the
				// next-round `[Continue]` message tells the model the task is
				// still pending. Observed on the World Cup t-shirts chain where
				// `create_post` ("Create the requested blog post or page") was
				// verified but appeared in the [Continue] Remaining list,
				// confusing the wrap round.
				var DONE_STATES = ['done', 'completed', 'verified'];
				execution.tasks.forEach(function (task) {
					if (!task || !task.label) return;
					var isDone = DONE_STATES.indexOf(task.status) !== -1;
					if (task.key === 'optimize_seo' && !isDone) {
						seoRemainingForTarget = true;
					}
					if (isDone) {
						completed.push(task.label);
					} else {
						remaining.push(task.label);
					}
				});
			}

			if (completed.length) {
				summary = 'Completed: ' + completed.join('; ') + '.';
			}
			if (remaining.length) {
				summary += ' Remaining: ' + remaining.join('; ') + '.';
			}
			if (!remaining.length && completed.length) {
				summary += ' All requested steps appear complete. Do not continue automatically unless the user explicitly asks for more work.';
			}

			if (postTitle && summary.toLowerCase().indexOf(String(postTitle).toLowerCase()) === -1) {
				summary += ' Continue using "' + postTitle + '".';
			}
			if (seoRemainingForTarget && postId) {
				summary += ' Optimize SEO only for this existing post. Do not scan or change any other posts or pages.';
			}

			var extras = [];
			if (postId) extras.push('post_id=' + postId);
			if (url) extras.push('url=' + url);
			if (extras.length) summary += ' [' + extras.join(', ') + ']';

			if (shouldEmitWrap) {
				return '[Continue] ' + summary + ' Do not repeat completed steps or recreate completed content. The requested work is complete; emit a concise final summary for the user and do not call tools.';
			}

			return '[Continue] ' + summary + ' Do not repeat completed steps or recreate completed content. Please continue with the remaining steps from my original request.';
		},

		buildCompactionContinuationMessage: function (result) {
			var parts = ['[Continue] Context was compressed mid-task. The conversation summary above contains all prior decisions and progress.'];
			var cp = (result && result.checkpoint) ? result.checkpoint : {};
			var exec = cp.execution || {};
			var target = exec.current_target || {};

			if (target.post_title) {
				parts.push('Working on: "' + target.post_title + '" (post_id=' + (target.post_id || '?') + ').');
			}

			var completed = exec.completed_steps || [];
			if (!completed.length && exec.tasks && exec.tasks.length) {
				completed = exec.tasks.filter(function (task) {
					return task && (task.status === 'done' || task.status === 'completed') && task.label;
				}).map(function (task) {
					return task.label;
				});
			}
			if (completed.length) {
				parts.push('Already completed: ' + completed.join(', ') + '.');
			}

			// Include loaded tool groups so AI doesn't re-load them
			var loadedGroups = (result && result.loaded_groups) ? result.loaded_groups : (cp.loaded_tool_groups || []);
			if (loadedGroups.length) {
				parts.push('Tools already loaded: ' + loadedGroups.join(', ') + '. Do NOT call discover_tools or load_tools for these.');
			}

			parts.push('CRITICAL: Do NOT re-discover or re-load tools. Do NOT recreate content that already exists. Do NOT repeat completed steps. Continue with the NEXT remaining step only.');
			return parts.join(' ');
		},

		isSilentContinuationResult: function (result) {
			return !!(result && result.silent_continuation);
		},

		normalizeStepStatus: function (status) {
			if (status === 'compressing_context') return 'reading';
			if (status === 'in_progress') return 'running';
			if (status === 'approved' || status === 'succeeded' || status === 'kept') return 'done';
			return status || 'done';
		},

		getSilentContinuationStep: function () {
			return {
				status: 'compressing_context',
				label: __( 'Compressing context...', 'pressark' ),
				tool: '_context_compaction',
			};
		},

		renderSilentContinuationStep: function (result, beforeEl) {
			var steps = (result && result.steps && result.steps.length > 0)
				? result.steps
				: [this.getSilentContinuationStep()];

			if (beforeEl) {
				this.renderActivityStripBefore(steps, beforeEl);
			} else {
				this.renderActivityStrip(steps);
			}
		},

		shouldAutoResume: function (result) {
			var continuation = (result && result.continuation) ? result.continuation : {};

			// Phase 3b: the server-side continuation evaluator is authoritative.
			// This boolean may represent either more work or one final wrap round;
			// the reason_code/evaluator payload names which case it is.
			if (typeof continuation.should_auto_resume === 'boolean') {
				return continuation.should_auto_resume;
			}
			if (typeof continuation.evaluator_should_resume === 'boolean' || typeof continuation.evaluator_should_emit_wrap === 'boolean') {
				return continuation.evaluator_should_resume === true || continuation.evaluator_should_emit_wrap === true;
			}

			return false;
		},

		shouldAutoContinueCompactedRun: function (result) {
			var outcomeStatus = this.getApprovalOutcomeStatus(result);
			if (!result || result.is_error || result.cancelled || (outcomeStatus && outcomeStatus !== 'approved')) {
				return false;
			}

			if ((result.type || 'final_response') !== 'final_response') {
				return false;
			}

			if ((result.exit_reason || '') !== 'max_request_icus_compacted') {
				return false;
			}

			return !!(result.checkpoint && typeof result.checkpoint === 'object');
		},

		applyResultState: function (result) {
			if (!result || typeof result !== 'object') {
				return;
			}

			if (result.usage) {
				this.updateUsage(result.usage);
			}
			if (result.token_status) {
				this.updateTokenDisplay(result.token_status);
			}
			if (result.chat_id && (!this.currentChatId || this.currentChatId !== result.chat_id)) {
				this.currentChatId = result.chat_id;
			}
			if (result.loaded_groups && Array.isArray(result.loaded_groups)) {
				this.loadedGroups = result.loaded_groups;
			}
			if (result.checkpoint && typeof result.checkpoint === 'object') {
				this.checkpoint = result.checkpoint;
			}
			if (result.plan_info) {
				window.pressarkData.plan_info = result.plan_info;
				this.renderQuotaBar();
			}
			if (Array.isArray(result.plan_steps) && result.plan_steps.length > 0) {
				this.syncPlanTrackerFromPlan(result);
			} else if (result.checkpoint && Array.isArray(result.checkpoint.plan_steps) && result.checkpoint.plan_steps.length > 0) {
				this.syncPlanTrackerFromPlan(result.checkpoint);
			} else if (result.activity_strip && Array.isArray(result.activity_strip.items) && result.activity_strip.items.length > 0) {
				this.syncPlanTrackerFromActivity(result.activity_strip.items);
			}
		},

		continueCompactedRun: function (result) {
			if (!this.shouldAutoContinueCompactedRun(result) || this.isSending) {
				return false;
			}

			this.applyResultState(result);
			this.autoSaveChat();

			var self = this;
			var resumeDelay = this.isSilentContinuationResult(result) ? 100 : 150;
			setTimeout(function () {
				self.sendMessage(self.buildCompactionContinuationMessage(result));
			}, resumeDelay);

			return true;
		},

		resolveContinuationPostId: function (message, fallbackPostId) {
			var execution = (this.checkpoint && this.checkpoint.execution) ? this.checkpoint.execution : {};
			var target = (execution && execution.current_target) ? execution.current_target : {};
			var targetId = parseInt(target.post_id || 0, 10);
			if (targetId > 0) return targetId;

			var match = String(message || '').match(/\bpost_id\s*=\s*(\d+)\b/i);
			if (match && match[1]) {
				return parseInt(match[1], 10) || fallbackPostId || 0;
			}

			return fallbackPostId || 0;
		},

		updateUsageDisplay: function () {
			this.renderQuotaBar();
		},

		// ── Undo ──────────────────────────────────────────────────────

		bindUndoButton: function (btn) {
			if (!btn) return;
			var self = this;
			btn.addEventListener('click', function () {
				var logId = parseInt(btn.dataset.logId, 10);
				if (!logId) return;

				btn.textContent = __( 'Undoing...', 'pressark' );
				btn.disabled = true;

				var data = window.pressarkData;
				fetch(data.restUrl + 'undo', {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'X-WP-Nonce': data.nonce,
					},
					body: JSON.stringify({ log_id: logId }),
				})
					.then(function (r) { return r.json(); })
					.then(function (result) {
						var parent = btn.parentNode;
						if (result.success) {
							var contentEl = parent.querySelector('.pressark-message-content') || parent.querySelector('span');
							if (contentEl) {
								contentEl.innerHTML = pwIcon('undo') + ' ' + self.escapeHtml(__( 'Undone - restored previous version', 'pressark' ));
							}
							btn.remove();
						} else {
							btn.textContent = result.message || __( 'Undo failed', 'pressark' );
							btn.disabled = true;
						}
						self.autoSaveChat();
					})
					.catch(function () {
						btn.textContent = __( 'Undo failed', 'pressark' );
						btn.disabled = true;
					});
			});
		},

		rebindUndoButtons: function () {
			var btns = this.messagesEl.querySelectorAll('.pressark-undo-btn');
			for (var i = 0; i < btns.length; i++) {
				this.bindUndoButton(btns[i]);
			}
			var retryBtns = this.messagesEl.querySelectorAll('.pressark-retry-btn');
			for (var j = 0; j < retryBtns.length; j++) {
				this.bindRetryButton(retryBtns[j]);
			}
		},

		// ── Retry ─────────────────────────────────────────────────────

		bindRetryButton: function (btn) {
			if (!btn) return;
			var self = this;
			btn.addEventListener('click', function () {
				if (self.lastUserMessage) {
					self.inputEl.value = self.lastUserMessage;
					self.sendMessage();
				}
			});
		},

		// ── Scroll & Typing ───────────────────────────────────────────

		scrollToBottom: function () {
			var el = this.messagesEl;
			setTimeout(function () {
				el.scrollTop = el.scrollHeight;
			}, 50);
		},

		showTyping: function (text) {
			this.removeTypingIndicator();

			var indicator = document.createElement('div');
			indicator.className = 'pressark-typing-indicator';
			indicator.innerHTML =
				'<div class="pressark-message-content pressark-thinking-content">' +
				'<span class="pressark-thinking-mark">' + this.getSparkMarkup() + '</span>' +
				'<span class="pressark-thinking-copy">' + this.escapeHtml(text || __( 'PressArk is thinking', 'pressark' )) + '</span>' +
				'</div>';

			this.messagesEl.appendChild(indicator);
			this.scrollToBottom();
			this.startThinkingSpark(indicator);
		},

		startThinkingSpark: function (indicator) {
			var rayA = indicator.querySelector('.pressark-spark-mark__ray-a');
			var core = indicator.querySelector('.pressark-spark-mark__core');
			if (!rayA) return;
			var start = performance.now();
			var self = this;
			function frame(now) {
				if (!indicator.isConnected) {
					self._thinkingSparkFrame = null;
					return;
				}
				var t = (now - start) / 1000;
				var aDeg = (t * 225) % 360;
				var aScale = 0.88 + 0.16 * Math.sin(t * 3.4);
				rayA.style.transform = 'rotate(' + aDeg.toFixed(2) + 'deg) scale(' + aScale.toFixed(3) + ')';
				if (core) {
					var pulse = 0.85 + 0.25 * (0.5 + 0.5 * Math.sin(t * 4.4));
					core.style.transform = 'scale(' + pulse.toFixed(3) + ')';
				}
				self._thinkingSparkFrame = requestAnimationFrame(frame);
			}
			this._thinkingSparkFrame = requestAnimationFrame(frame);
		},

		removeTypingIndicator: function () {
			if (this._thinkingSparkFrame) {
				cancelAnimationFrame(this._thinkingSparkFrame);
				this._thinkingSparkFrame = null;
			}
			var existing = this.messagesEl.querySelector('.pressark-typing-indicator');
			if (existing) existing.remove();
		},

		hideTyping: function () {
			this.removeTypingIndicator();
		},

		// ── Quota Bar ─────────────────────────────────────────────────

		formatCredits: function (n) {
			if (n >= 1000000) {
				var m = Math.round(n / 100000) / 10;
				return (m % 1 === 0 ? m.toFixed(0) : m.toFixed(1)) + 'M';
			}
			if (n >= 1000) return Math.round(n / 1000) + 'K';
			return String(n);
		},

		formatTokens: function (n) {
			return this.formatCredits(n);
		},

		formatResetDate: function (isoString) {
			if (!isoString) return '';
			var parsed = new Date(isoString);
			if (isNaN(parsed.getTime())) return '';
			return parsed.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
		},

		getBillingState: function (info) {
			var state = (info && info.billing_state) || {};
			var isByok = !!(info && info.is_byok);
			var monthlyRemaining = info ? (info.monthly_included_remaining || info.monthly_remaining || 0) : 0;
			var purchasedRemaining = info ? (info.purchased_credits_remaining || info.credits_remaining || 0) : 0;
			var legacyRemaining = info ? (info.legacy_bonus_remaining || 0) : 0;
			var totalRemaining = info ? (info.total_remaining || info.icus_remaining || info.tokens_remaining || 0) : 0;
			var hasMonthly = monthlyRemaining > 0;
			var hasPurchased = purchasedRemaining > 0;
			var hasLegacy = legacyRemaining > 0;
			var spendSource = state.spend_source;

			if (!spendSource) {
				if (isByok) spendSource = 'byok';
				else if (hasMonthly && !hasPurchased && !hasLegacy) spendSource = 'monthly_included';
				else if (!hasMonthly && hasPurchased && !hasLegacy) spendSource = 'purchased_credits';
				else if (!hasMonthly && !hasPurchased && hasLegacy) spendSource = 'legacy_bonus';
				else if ((hasMonthly && hasPurchased) || (hasMonthly && hasLegacy) || (hasPurchased && hasLegacy)) spendSource = 'mixed';
				else spendSource = totalRemaining > 0 ? 'monthly_included' : 'depleted';
			}

			var authorityMode = state.authority_mode || (isByok ? 'byok' : ((info && info.verified_handshake) ? 'bank_verified' : 'bank_provisional'));
			var serviceState = state.service_state || ((info && info.offline) ? 'offline_assisted' : 'normal');
			var handshakeState = state.handshake_state || (isByok ? 'byok' : ((info && info.verified_handshake) ? 'verified' : 'provisional'));

			return {
				authority_mode: authorityMode,
				handshake_state: handshakeState,
				service_state: serviceState,
				spend_source: spendSource,
				authority_label: state.authority_label || (authorityMode === 'bank_verified' ? __( 'Bank verified', 'pressark' ) : (authorityMode === 'byok' ? 'BYOK' : __( 'Bank provisional', 'pressark' ))),
				service_label: state.service_label || (serviceState === 'offline_assisted' ? __( 'Offline assisted', 'pressark' ) : (serviceState === 'degraded' ? __( 'Degraded', 'pressark' ) : __( 'Normal', 'pressark' ))),
				spend_label: state.spend_label || (function () {
					if (spendSource === 'purchased_credits') return __( 'Purchased credits', 'pressark' );
					if (spendSource === 'legacy_bonus') return __( 'Legacy bonus', 'pressark' );
					if (spendSource === 'mixed') return __( 'Mixed sources', 'pressark' );
					if (spendSource === 'depleted') return __( 'Depleted', 'pressark' );
					return spendSource === 'byok' ? 'BYOK' : __( 'Monthly included', 'pressark' );
				}()),
				service_notice: state.service_notice || (serviceState === 'offline_assisted' ? __( 'Using the last bank snapshot locally until the bank is reachable again.', 'pressark' ) : (serviceState === 'degraded' ? __( 'Bank truth is still authoritative while a dependency is degraded.', 'pressark' ) : '')),
				estimate_notice: state.estimate_notice || (isByok ? __( 'Provider usage is separate from bundled credits.', 'pressark' ) : __( 'Plugin-side token and ICU estimates are advisory until bank settlement.', 'pressark' ))
			};
		},

		renderQuotaBar: function () {
			if (!this.quotaBarEl) return;

			var info = (window.pressarkData || {}).plan_info;
			if (!info) return;

			var billingState = this.getBillingState(info);
			var settingsUrl = (window.pressarkData || {}).settings_url || '#';
			var countLabel = '';
			var linkHtml = '';
			var progressPct = 0;
			var depleted = false;

			if (info.is_byok) {
				countLabel = __( 'Your API key', 'pressark' );
				progressPct = 0;
				linkHtml = '<a href="' + this.escapeHtml(settingsUrl) + '">' + this.escapeHtml(__( 'Manage', 'pressark' )) + '</a>';
			} else {
				var creditsUsedNum = info.icus_used || info.tokens_used || 0;
				var monthlyBudgetNum = info.monthly_included_icu_budget || info.monthly_icu_budget || info.icu_budget || info.token_budget || 0;
				var purchasedRemainingNum = info.purchased_credits_remaining || info.credits_remaining || 0;
				var legacyRemainingNum = info.legacy_bonus_remaining || 0;
				var totalRemainingNum = info.total_remaining || info.icus_remaining || info.tokens_remaining || 0;
				var creditsUsed = this.formatCredits(creditsUsedNum);
				var monthlyBudget = this.formatCredits(monthlyBudgetNum);
				countLabel = creditsUsed + ' / ' + monthlyBudget;
				progressPct = monthlyBudgetNum > 0 ? Math.max(4, Math.min(100, Math.round((creditsUsedNum / monthlyBudgetNum) * 100))) : 0;

				if (info.monthly_exhausted && totalRemainingNum <= 0 && purchasedRemainingNum <= 0 && legacyRemainingNum <= 0) {
					depleted = true;
					linkHtml = '<a href="' + this.escapeHtml(info.upgrade_url || settingsUrl) + '">' + this.escapeHtml(__( 'Manage billing', 'pressark' )) + '</a>';
				} else {
					linkHtml = '<a href="' + this.escapeHtml(settingsUrl) + '">' + this.escapeHtml(__( 'Usage', 'pressark' )) + '</a>';
				}
			}

			this.quotaBarEl.classList.toggle('pressark-quota-depleted', depleted);

			// Tooltip carries the diagnostic detail so it stays accessible without crowding the chrome.
			var tooltipParts = [];
			if (!info.is_byok) {
				var resetLabel = this.formatResetDate(info.next_reset_at || info.billing_period_end || '');
				/* translators: %s: credit reset date. */
				if (resetLabel) tooltipParts.push(sprintf( __( 'Resets %s', 'pressark' ), resetLabel ));
				if (billingState.spend_label) tooltipParts.push(billingState.spend_label);
				if (billingState.authority_label) tooltipParts.push(billingState.authority_label);
				if (billingState.service_state !== 'normal' && billingState.service_notice) tooltipParts.push(billingState.service_notice);
			} else {
				tooltipParts.push(__( 'Bundled credits bypassed', 'pressark' ));
			}
			var tooltip = tooltipParts.join(' · ');

			this.quotaBarEl.innerHTML =
				'<div class="pressark-quota-shell"' + (tooltip ? ' title="' + this.escapeHtml(tooltip) + '"' : '') + '>' +
					'<span class="pressark-quota-label">' + this.escapeHtml(countLabel) + '</span>' +
					'<span class="pressark-quota-track"><i class="pressark-quota-fill" style="width:' + progressPct + '%"></i></span>' +
					linkHtml +
				'</div>';
		},

		updateUsage: function (usage) {
			if (window.pressarkData) {
				window.pressarkData.usage = usage;
			}
			this.renderQuotaBar();
		},

		updateTokenDisplay: function (status) {
			if (window.pressarkData && window.pressarkData.plan_info && status) {
				window.pressarkData.plan_info = Object.assign({}, window.pressarkData.plan_info, {
					icus_used: status.icus_used,
					icus_remaining: status.icus_remaining,
					icu_budget: status.icu_budget || window.pressarkData.plan_info.icu_budget,
					credits_remaining: status.purchased_credits_remaining || status.credits_remaining,
					purchased_credits_remaining: status.purchased_credits_remaining || status.credits_remaining,
					legacy_bonus_remaining: status.legacy_bonus_remaining,
					monthly_remaining: status.monthly_remaining,
					monthly_included_remaining: status.monthly_included_remaining,
					monthly_exhausted: status.monthly_exhausted,
					using_purchased_credits: status.using_purchased_credits,
					using_legacy_bonus: status.using_legacy_bonus,
					total_available: status.total_available,
					total_remaining: status.total_remaining,
					raw_tokens_used: status.raw_tokens_used,
					next_reset_at: status.next_reset_at,
					billing_period_start: status.billing_period_start,
					billing_period_end: status.billing_period_end,
					uses_anniversary_reset: status.uses_anniversary_reset,
					billing_authority: status.billing_authority,
					billing_state: status.billing_state,
					billing_service_state: status.billing_service_state,
					billing_handshake_state: status.billing_handshake_state,
					billing_spend_source: status.billing_spend_source,
					verified_handshake: status.verified_handshake,
					provisional_handshake: status.provisional_handshake,
					offline: status.offline,
					reserve_certainty: status.reserve_certainty,
					reserve_envelope: status.reserve_envelope
				});
			}
			this.renderQuotaBar();
		},

		// ── Activity Strip (Agentic Loop Steps) ──────────────────────

		renderActivityStrip: function (steps) {
			if (!steps || !steps.length) return;

			var strip = document.createElement('div');
			strip.className = 'pressark-activity-strip';

			for (var i = 0; i < steps.length; i++) {
				var step = steps[i];
				var row = document.createElement('div');
				var status = this.normalizeStepStatus(step.status);
				row.className = 'pressark-step pressark-step--' + status;

				var icon = '';
				switch (status) {
					case 'reading':
						icon = '<span class="pressark-step-icon pressark-step-icon--reading">' + pwIcons.loader + '</span>';
						break;
					case 'done':
						icon = '<span class="pressark-step-icon pressark-step-icon--done">' + pwIcons.check + '</span>';
						break;
					case 'preparing_preview':
						icon = '<span class="pressark-step-icon pressark-step-icon--preview">' + pwIcons.dot + '</span>';
						break;
					case 'needs_confirm':
						icon = '<span class="pressark-step-icon pressark-step-icon--confirm">' + pwIcons.warning + '</span>';
						break;
					default:
						icon = '<span class="pressark-step-icon">' + pwIcons.dot + '</span>';
				}

				row.innerHTML = icon + '<span class="pressark-step-label">' + this.escapeHtml(step.content || step.activeForm || step.label || step.tool || '') + '</span>';
				strip.appendChild(row);
			}

			this.messagesEl.appendChild(strip);
			this.scrollToBottom();
		},

		/**
		 * Render activity strip just before a specific element (used at stream finalize).
		 */
		renderActivityStripBefore: function (steps, beforeEl) {
			if (!steps || !steps.length) return;

			var strip = document.createElement('div');
			strip.className = 'pressark-activity-strip';

			for (var i = 0; i < steps.length; i++) {
				var step = steps[i];
				var row = document.createElement('div');
				var status = this.normalizeStepStatus(step.status);
				row.className = 'pressark-step pressark-step--' + status;

				var icon = '';
				switch (status) {
					case 'reading':
						icon = '<span class="pressark-step-icon pressark-step-icon--reading">' + pwIcons.loader + '</span>';
						break;
					case 'done':
						icon = '<span class="pressark-step-icon pressark-step-icon--done">' + pwIcons.check + '</span>';
						break;
					case 'preparing_preview':
						icon = '<span class="pressark-step-icon pressark-step-icon--preview">' + pwIcons.dot + '</span>';
						break;
					case 'needs_confirm':
						icon = '<span class="pressark-step-icon pressark-step-icon--confirm">' + pwIcons.warning + '</span>';
						break;
					default:
						icon = '<span class="pressark-step-icon">\u00B7</span>';
				}

				row.innerHTML = icon + '<span class="pressark-step-label">' + this.escapeHtml(step.content || step.activeForm || step.label || step.tool || '') + '</span>';
				strip.appendChild(row);
			}

			this.messagesEl.insertBefore(strip, beforeEl);
			this.scrollToBottom();
		},

		// ── Live Preview System ──────────────────────────────────────

		getResultActivityItems: function (result) {
			if (!result || typeof result !== 'object') return [];

			if (result.activity_strip && Array.isArray(result.activity_strip.items) && result.activity_strip.items.length > 0) {
				return result.activity_strip.items;
			}

			if (Array.isArray(result.steps) && result.steps.length > 0) {
				return result.steps;
			}

			return [];
		},

		normalizeActivityStatus: function (status) {
			var normalized = this.normalizeStepStatus(status);
			switch (normalized) {
				case 'reading':
				case 'running':
					return 'running';
				case 'preparing_preview':
				case 'needs_confirm':
				case 'waiting':
					return 'waiting';
				case 'done':
				case 'completed':
				case 'succeeded':
				case 'approved':
				case 'discarded':
				case 'declined':
					return 'done';
				case 'retrying':
					return 'retrying';
				case 'queued':
					return 'queued';
				case 'degraded':
					return 'degraded';
				case 'blocked':
				case 'failed':
				case 'error':
					return 'blocked';
				default:
					return normalized || 'queued';
			}
		},

		getActivityIconMarkup: function (status) {
			switch (status) {
				case 'running':
					return '<span class="pressark-step-icon pressark-step-icon--running">' + pwIcons.loader + '</span>';
				case 'done':
					return '<span class="pressark-step-icon pressark-step-icon--done">' + pwIcons.check + '</span>';
				case 'waiting':
					return '<span class="pressark-step-icon pressark-step-icon--waiting">' + pwIcons.dot + '</span>';
				case 'retrying':
					return '<span class="pressark-step-icon pressark-step-icon--retrying">' + pwIcons.refresh + '</span>';
				case 'degraded':
					return '<span class="pressark-step-icon pressark-step-icon--degraded">' + pwIcons.alertCircle + '</span>';
				case 'blocked':
					return '<span class="pressark-step-icon pressark-step-icon--blocked">' + pwIcons.xCircle + '</span>';
				default:
					return '<span class="pressark-step-icon pressark-step-icon--queued">' + pwIcons.statusDot + '</span>';
			}
		},

		buildActivityStripElement: function (items) {
			if (!items || !items.length) return null;

			var strip = document.createElement('div');
			strip.className = 'pressark-activity-strip';

			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				if (!item) continue;

				var label = item.label || item.tool || '';
				if (!label) continue;

				var detail = item.detail || '';
				var status = this.normalizeActivityStatus(item.status);
				var row = document.createElement('div');
				row.className = 'pressark-step pressark-step--' + status;
				if (item.reason) {
					row.setAttribute('data-reason', item.reason);
				}

				row.innerHTML = this.getActivityIconMarkup(status) +
					'<span class="pressark-step-copy">' +
					'<span class="pressark-step-label">' + this.escapeHtml(label) + '</span>' +
					(detail ? '<span class="pressark-step-detail">' + this.escapeHtml(detail) + '</span>' : '') +
					'</span>';
				strip.appendChild(row);
			}

			return strip.childNodes.length ? strip : null;
		},

		renderActivityStrip: function () {
			// Activity strip intentionally hidden from chat UI — diagnostics belong elsewhere.
		},

		renderActivityStripBefore: function () {
			// Activity strip intentionally hidden from chat UI — diagnostics belong elsewhere.
		},

		openPreview: function (data) {
			var self = this;

			// Narrow the chat panel for preview mode.
			this.panel.classList.add('pressark-preview-mode');

			// Build the diff panel.
			var diffHTML = this.buildDiffHTML(data.diff || []);

			// Create preview overlay on wp-admin content area.
			var overlay = document.createElement('div');
			overlay.id = 'pressark-preview-overlay';
			overlay.className = 'pressark-preview-overlay';
			overlay.innerHTML =
				'<div class="pressark-preview-overlay__header">' +
					'<span class="pressark-preview-overlay__title">' + this.escapeHtml(__( 'Preview Changes', 'pressark' )) + '</span>' +
					'<span class="pressark-preview-overlay__badge">' + this.escapeHtml(__( 'Unsaved', 'pressark' )) + '</span>' +
				'</div>' +
				'<div class="pressark-preview-body">' +
					'<div class="pressark-preview-diff">' + diffHTML + '</div>' +
					'<iframe class="pressark-preview-iframe" src="' + this.escapeHtml(data.preview_url) + '"></iframe>' +
				'</div>';

			// Insert into wp-admin content area.
			var wpBody = document.getElementById('wpbody-content') || document.getElementById('wpbody') || document.body;
			wpBody.appendChild(overlay);

			// Show Keep/Discard buttons in chat panel.
			this.showPreviewActions(data);
		},

		buildDiffHTML: function (diff) {
			if (!diff || !diff.length) {
				return '<p class="pressark-diff-empty">' + this.escapeHtml(__( 'No field-level changes to display.', 'pressark' )) + '</p>';
			}

			// Flatten the nested diff format from PHP.
			// PHP sends: [{type, label, items: [{field, old, new}]}]
			// We need flat rows: [{field, before, after}]
			var rows = [];
			for (var i = 0; i < diff.length; i++) {
				var d = diff[i];
				if (d.items && Array.isArray(d.items)) {
					// Nested format from preview system
					for (var j = 0; j < d.items.length; j++) {
						var item = d.items[j];
						rows.push({
							field: item.field || '',
							before: Object.prototype.hasOwnProperty.call(item, 'old') ? item.old : item.before,
							after: Object.prototype.hasOwnProperty.call(item, 'new') ? item['new'] : item.after
						});
					}
				} else if (d.changes && Array.isArray(d.changes)) {
					// Nested format from confirm card system
					for (var k = 0; k < d.changes.length; k++) {
						var change = d.changes[k];
						rows.push({
							field: change.field || '',
							before: change.before,
							after: change.after
						});
					}
				} else {
					// Already flat format (field, before, after)
					rows.push({
						field: d.field || '',
						before: Object.prototype.hasOwnProperty.call(d, 'old') ? d.old : d.before,
						after: Object.prototype.hasOwnProperty.call(d, 'new') ? d['new'] : d.after
					});
				}
			}

			if (!rows.length) {
				return '<p class="pressark-diff-empty">' + this.escapeHtml(__( 'No field-level changes to display.', 'pressark' )) + '</p>';
			}

			var html = '<table class="pressark-diff-table">';
			html += '<thead><tr><th>' + this.escapeHtml(__( 'Field', 'pressark' )) + '</th><th>' + this.escapeHtml(__( 'Before', 'pressark' )) + '</th><th>' + this.escapeHtml(__( 'After', 'pressark' )) + '</th></tr></thead><tbody>';

			for (var r = 0; r < rows.length; r++) {
				var row = rows[r];
				var diffBefore = this.formatPreviewValue(row.before);
				var diffAfter = this.formatPreviewValue(row.after);
				html += '<tr>';
				html += '<td class="pressark-diff-field">' + this.escapeHtml(row.field) + '</td>';
				html += '<td class="pressark-diff-before">' + this.escapeHtml(this.truncateText(diffBefore, 150)) + '</td>';
				html += '<td class="pressark-diff-after">' + this.escapeHtml(this.truncateText(diffAfter, 150)) + '</td>';
				html += '</tr>';
			}

			html += '</tbody></table>';
			return html;
		},

		truncateText: function (text, maxLen) {
			if (typeof text !== 'string') text = String(text);
			if (text.length <= maxLen) return text;
			return text.substring(0, maxLen) + '...';
		},

		showPreviewActions: function (previewData) {
			var self = this;
			var sessionId = previewData && previewData.preview_session_id ? previewData.preview_session_id : '';
			var diff = previewData && Array.isArray(previewData.diff) ? previewData.diff : [];
			var riskReceipt = previewData && previewData.risk_receipt ? previewData.risk_receipt : null;
			if (this.activePreviewFooterEl && this.activePreviewFooterEl.parentNode) {
				this.activePreviewFooterEl.parentNode.removeChild(this.activePreviewFooterEl);
			}

			var actionsDiv = document.createElement('div');
			actionsDiv.className = 'pressark-preview-footer';
			actionsDiv.innerHTML =
				this.renderRiskReceipt(riskReceipt) +
				'<div class="pressark-preview-footer__actions">' +
					'<button type="button" class="pressark-btn pressark-btn--keep" data-session="' + this.escapeHtml(sessionId) + '">' +
						this.getPreviewButtonContent(pwIcons.check, __( 'Keep Changes', 'pressark' )) +
					'</button>' +
					'<button type="button" class="pressark-btn pressark-btn--discard" data-session="' + this.escapeHtml(sessionId) + '">' +
						this.getPreviewButtonContent(pwIcons.x, __( 'Discard', 'pressark' )) +
					'</button>' +
				'</div>';

			// Add Customizer handoff button if changes are Customizer-eligible.
			if (diff && this.isCustomizerEligible(diff) && window.pressarkData && window.pressarkData.admin_url) {
				var customizerUrl = window.pressarkData.admin_url + 'customize.php?autofocus[section]=title_tagline';
				actionsDiv.innerHTML +=
					'<a href="' + this.escapeHtml(customizerUrl) + '" target="_blank" rel="noopener noreferrer" class="pressark-preview-footer__link">' +
					this.escapeHtml(__( 'View & fine-tune in Customizer', 'pressark' )) + '</a>';
			}

			this.messagesEl.appendChild(actionsDiv);
			this.activePreviewFooterEl = actionsDiv;
			this.scrollToBottom();

			var keepBtn = actionsDiv.querySelector('.pressark-btn--keep');
			var discardBtn = actionsDiv.querySelector('.pressark-btn--discard');

			keepBtn.addEventListener('click', function () {
				self.setPreviewFooterBusy(actionsDiv, true, 'keep');
				self.confirmPreview(sessionId, 'keep');
			});

			discardBtn.addEventListener('click', function () {
				self.setPreviewFooterBusy(actionsDiv, true, 'discard');
				self.confirmPreview(sessionId, 'discard');
			});
		},

		confirmPreview: function (sessionId, action) {
			var self = this;
			var data = window.pressarkData;
			var endpoint = action === 'keep' ? 'preview/keep' : 'preview/discard';

			fetch(data.restUrl + endpoint, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce,
				},
				body: JSON.stringify({ session_id: sessionId }),
			})
				.then(function (response) { return response.json(); })
				.then(function (result) {
					var settlement = self.getApprovalSettlement(result);
					if (result.success && settlement.acknowledged && settlement.settled) {
						var outcomeStatus = settlement.status || (action === 'keep' ? 'approved' : 'discarded');
						self.closePreview(outcomeStatus);
						var displayMsg = result.message || (outcomeStatus === 'approved'
							? __( 'Changes applied successfully.', 'pressark' )
							: __( 'Preview discarded.', 'pressark' ));
						// v3.1.0: Append verification summary if present.
						if (outcomeStatus === 'approved' && result.verification && result.verification.message) {
							displayMsg += '\n\n' + result.verification.message;
						}
						self.appendAssistantResultMessage(displayMsg, result);
						// Save as card summary so history renders the nice status card.
						var cardStatus = outcomeStatus === 'approved'
							? 'applied'
							: (outcomeStatus === 'discarded' ? 'discarded' : outcomeStatus);
						var historyMsg = '[PRESSARK_CARD:' + cardStatus + ']' + (result.post_title || 'Changes') + '||' + displayMsg;
						self.conversation.push({ role: 'assistant', content: historyMsg });

						if (result.checkpoint && typeof result.checkpoint === 'object') {
							self.checkpoint = result.checkpoint;
						}

						// v3.7.3: Auto-resume with enriched continuation context.
						// Uses [Continue] prefix so classify_task routes based on
						// the original user request, not this continuation marker.
						if (outcomeStatus === 'approved' && self.shouldAutoResume(result)) {
							setTimeout(function () {
								self.sendMessage(self.buildContinuationMessage(result, 'Changes applied successfully.'));
							}, 600);
						} else if (outcomeStatus === 'approved' && result.continuation && result.continuation.pause_message) {
							self.addMessage('ai', result.continuation.pause_message);
							self.conversation.push({ role: 'assistant', content: result.continuation.pause_message });
						}
					} else {
						self.setPreviewFooterBusy(self.activePreviewFooterEl, false);
						self.addMessage('error', result.message || __( 'PressArk did not confirm that the preview was settled. Please try again.', 'pressark' ));
					}

					if (result.usage) {
						self.updateUsage(result.usage);
					}
				})
				.catch(function (err) {
					self.setPreviewFooterBusy(self.activePreviewFooterEl, false);
					var failedLabel = '';
					if (action === 'keep') {
						/* translators: %s: error message. */
						failedLabel = __( 'Failed to keep preview: %s', 'pressark' );
					} else {
						/* translators: %s: error message. */
						failedLabel = __( 'Failed to discard preview: %s', 'pressark' );
					}
					self.addMessage('error', sprintf( failedLabel, err.message ));
				});
		},

		closePreview: function (status) {
			// Remove the preview overlay from wp-admin.
			var overlay = document.getElementById('pressark-preview-overlay');
			if (overlay) {
				overlay.remove();
			}

			// Restore chat panel width.
			this.panel.classList.remove('pressark-preview-mode');

			if (status) {
				this.setPreviewFooterSettled(status);
			} else if (this.activePreviewFooterEl) {
				var btns = this.activePreviewFooterEl.querySelectorAll('button');
				for (var i = 0; i < btns.length; i++) {
					btns[i].disabled = true;
				}
			}
		},

		// ── Request Lifecycle ─────────────────────────────────────────

		beginRequest: function () {
			var controller = new AbortController();
			this._activeRequest = { controller: controller, reader: null };
			this._toolProgressState = {};
			this.isSending = true;
			this.setSendButtonState('stop');
			return controller;
		},

		finishRequest: function () {
			this._activeRequest = null;
			this._activeRunId = null;
			this._toolProgressState = {};
			this.isSending = false;
			this.setSendButtonState('send');
			this.removeTypingIndicator();
		},

		sendCancelSignal: function (cancelPayload) {
			var data = window.pressarkData || {};
			var cancelUrl = (data.restUrl || '') + 'cancel';
			if (!cancelUrl) return;

			var params = new URLSearchParams();
			if (cancelPayload && cancelPayload.run_id) {
				params.append('run_id', String(cancelPayload.run_id));
			}
			if (cancelPayload && cancelPayload.chat_id) {
				params.append('chat_id', String(cancelPayload.chat_id));
			}
			if (data.nonce) {
				params.append('_wpnonce', String(data.nonce));
			}

			var beaconSent = false;
			try {
				if (navigator.sendBeacon) {
					beaconSent = navigator.sendBeacon(cancelUrl, params);
				}
			} catch (e) {
				beaconSent = false;
			}

			if (beaconSent) return;

			fetch(cancelUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				},
				body: params.toString(),
				credentials: 'same-origin',
				keepalive: true,
			}).catch(function () { /* fire-and-forget */ });
		},

		abortActiveRequest: function () {
			var cancelPayload = {};
			if (this._activeRunId) {
				cancelPayload.run_id = this._activeRunId;
			}
			if (this.currentChatId) {
				cancelPayload.chat_id = this.currentChatId;
			}

			// Notify the backend before aborting the stream. This is more
			// reliable in browsers/proxies where aborting a long-lived fetch
			// can starve or cancel follow-up requests on the same origin.
			this.sendCancelSignal(cancelPayload);

			if (this._activeRequest && this._activeRequest.controller) {
				this._activeRequest.controller.abort();
				return;
			}

			// UI/state safety net: if the stop affordance is still visible but
			// the active request handle has already been torn down locally,
			// still collapse the stop state after signalling the backend.
			this.finishRequest();
		},

		setSendButtonState: function (mode) {
			if (!this.sendBtn) return;
			if (mode === 'stop') {
				this.sendBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>';
				this.sendBtn.classList.add('pressark-send-btn--stop');
				this.sendBtn.setAttribute('aria-label', 'Stop');
				this.sendBtn.setAttribute('title', 'Stop');
			} else {
				this.sendBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>';
				this.sendBtn.classList.remove('pressark-send-btn--stop');
				this.sendBtn.setAttribute('aria-label', 'Send');
				this.sendBtn.setAttribute('title', 'Send');
			}
		},

		// ── Send Message ──────────────────────────────────────────────

		sendMessage: function (internalMessage) {
			if (this.isSending || this._confirmStreamActive) return;

			// Defensive: ensure message is always a string (guards against minifier
			// variable-shadowing bugs where a Response object could be passed).
			var message = String(internalMessage || this.inputEl.value.trim() || '');
			if (!message) return;

			if (!window.pressarkData.hasApiKey) {
				this.addMessage('error', __( 'API key not configured. Go to PressArk settings to add your key.', 'pressark' ));
				return;
			}

			// v4.4.0: Prefer streaming when enabled.
			if (window.pressarkData.streamingEnabled && typeof ReadableStream !== 'undefined') {
				return this.sendMessageStream(message, internalMessage);
			}

			if (!internalMessage) {
				this.lastUserMessage = message;
				this.addMessage('user', message);
				this.inputEl.value = '';
				this.inputEl.style.height = 'auto';
			}

			// v5.7.4 (2026-05-12): Bug 3 in-session JS half — don't push
			// auto-resume continuation markers ([Continue], [Confirmed]) into
			// the client-side conversation array. iter-14 stripped them from
			// server-side persistence; this is the matching client-side fix.
			// Without this, `conversation.slice(-25)` on the next sendMessage
			// re-ships these synthetic user turns to the server even within
			// the same tab session, polluting messages[] with harness control
			// markers that look like user input. Display already skips them
			// (no addMessage call when internalMessage is set).
			if (! /^\[(?:Continue|Confirmed)\]/i.test(message)) {
				this.conversation.push({ role: 'user', content: message });
			}

			var typingText = __( 'PressArk is thinking', 'pressark' );
			var lowerMsg = message.toLowerCase();
			if (lowerMsg.indexOf('seo') !== -1 || lowerMsg.indexOf('scan') !== -1) {
				typingText = __( 'Running analysis', 'pressark' );
			}
			if (lowerMsg.indexOf('security') !== -1) {
				typingText = __( 'Running security scan', 'pressark' );
			}
			if (lowerMsg.indexOf('store') !== -1 || lowerMsg.indexOf('woocommerce') !== -1 || lowerMsg.indexOf('products') !== -1) {
				typingText = __( 'Analyzing store', 'pressark' );
			}
			if (internalMessage) {
				typingText = __( 'Continuing', 'pressark' );
			}

			var controller = this.beginRequest();
			this.showTyping(typingText);

			var self = this;
			var data = window.pressarkData;
			var requestPostId = data.postId || 0;
			if (/^\[(?:Continue|Confirmed)\]/i.test(message)) {
				requestPostId = self.resolveContinuationPostId(message, requestPostId);
			}

			fetch(data.restUrl + 'chat', {
				method: 'POST',
				signal: controller.signal,
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce,
				},
				body: JSON.stringify({
					message: message,
					conversation: self.conversation.slice(-25),
					chat_id: self.currentChatId || 0,
					screen: data.screenId,
					post_id: requestPostId,
					deep_mode: self.deepModeActive,
					loaded_groups: self.loadedGroups,
					checkpoint: self.checkpoint,
				}),
			})
				.then(function (response) {
					if (response.status === 429) {
						return response.json().then(function (result) {
							self.finishRequest();
							var planInfo = result.plan_info || (window.pressarkData || {}).plan_info || {};
							var settingsUrl = (window.pressarkData || {}).settings_url || '#';
							self.addMessage('ai',
								result.message + '\n\n' +
								'[' + __( 'Manage billing', 'pressark' ) + '](' + (result.upgrade_url || settingsUrl) + ')\n' +
								'[' + __( 'Use your own API key', 'pressark' ) + '](' + settingsUrl + ')'
							);
							if (result.usage) {
								self.updateTokenDisplay(result.usage);
							}
							return;
						});
					}
					if (!response.ok) {
						return response.json()
							.catch(function () { return null; })
							.then(function (result) {
								/* translators: %d: HTTP status code. */
								throw new Error(sprintf( __( 'Server error (%d)', 'pressark' ), response.status ));
							});
					}
					return response.json();
				})
				.then(function (result) {
					if (!result) return; // Already handled (429)
					self.finishRequest();

					try {
						if (result.is_error) {
							self.appendRetryableError(result.reply || __( 'An error occurred.', 'pressark' ));
							return;
						}

					// v2.8.0: Handle entitlement denied at REST level.
					if (result.error === 'entitlement_denied') {
						var upgradeUrl = (result.upgrade_url || window.pressarkData.upgradeUrl || '#');
						self.addMessage('ai', result.message + '\n\n[' + __( 'Manage billing', 'pressark' ) + '](' + upgradeUrl + ')');
						return;
					}

					if (result.success === false && !result.reply) {
						result.reply = __( 'Something went wrong. Please try again.', 'pressark' );
					}

					var silentContinuation = self.isSilentContinuationResult(result);

					// Render activity strip from canonical backend state when present.
					var activityItems = self.getResultActivityItems(result);
					if (activityItems.length > 0) {
						self.renderActivityStrip(activityItems);
					} else if (silentContinuation) {
						self.renderSilentContinuationStep(result);
					}

					if (self.continueCompactedRun(result)) {
						return;
					}

					// Branch on response type.
					self.presentResult(result, { silentContinuation: silentContinuation });
					} catch (processingErr) {
						processingErr._pressarkResult = result;
						throw processingErr;
					}
				})
				.catch(function (err) {
					self.finishRequest();

					if (err && err.name === 'AbortError') {
						return;
					}

					var errorMessage = '';
					var responseResult = err && err._pressarkResult ? err._pressarkResult : null;
					if (responseResult) {
						console.error('PressArk response handling failed', err, responseResult);
						if (responseResult.type === 'preview' && responseResult.preview_session_id) {
							errorMessage = __( 'PressArk finished the request, but the panel could not render the preview. Refresh the page or open Activity to continue.', 'pressark' );
						} else {
							errorMessage = __( 'PressArk received a response, but the panel could not render it. Refresh the page and try again.', 'pressark' );
						}
					} else {
						console.error('PressArk request failed', err);
						errorMessage = __( 'Couldn\'t reach PressArk.', 'pressark' ) + ' ';
						var errMsg = err.message || '';
						if (errMsg.indexOf('401') !== -1 || errMsg.indexOf('403') !== -1) {
							errorMessage += __( 'Your session may have expired. Try refreshing the page.', 'pressark' );
						} else if (errMsg.indexOf('429') !== -1) {
							errorMessage += __( 'Too many requests. Please wait a moment and try again.', 'pressark' );
						} else if (errMsg.indexOf('500') !== -1) {
							errorMessage += __( 'Server error. Check your API key in PressArk settings.', 'pressark' );
						} else {
							errorMessage += __( 'Check your connection and try again.', 'pressark' );
						}
					}

					self.appendRetryableError(errorMessage);
				});
		},
		// ── SSE Streaming (v4.4.0) ──────────────────────────────────

		sendMessageStream: function (message, internalMessage) {
			if (this.isSending || this._confirmStreamActive) return;

			if (!internalMessage) {
				this.lastUserMessage = message;
				this.addMessage('user', message);
				this.inputEl.value = '';
				this.inputEl.style.height = 'auto';
			}

			// v5.7.4 (2026-05-12): Bug 3 in-session JS half — skip pushing
			// auto-resume continuation markers ([Continue], [Confirmed]) so
			// subsequent requests don't re-ship them as synthetic user turns.
			// Mirrors the matching guard in sendMessage above.
			if (! /^\[(?:Continue|Confirmed)\]/i.test(message)) {
				this.conversation.push({ role: 'user', content: message });
			}

			// Show thinking indicator while waiting for first token.
			var typingText = __( 'PressArk is thinking', 'pressark' );
			var lowerMsg = message.toLowerCase();
			if (lowerMsg.indexOf('seo') !== -1 || lowerMsg.indexOf('scan') !== -1) {
				typingText = __( 'Running analysis', 'pressark' );
			}
			if (lowerMsg.indexOf('security') !== -1) {
				typingText = __( 'Running security scan', 'pressark' );
			}
			if (lowerMsg.indexOf('store') !== -1 || lowerMsg.indexOf('woocommerce') !== -1 || lowerMsg.indexOf('products') !== -1) {
				typingText = __( 'Analyzing store', 'pressark' );
			}
			if (internalMessage) {
				typingText = __( 'Continuing', 'pressark' );
			}

			var controller = this.beginRequest();
			this.showTyping(typingText);

			var bubble = null; // Created lazily on first content event.
			var textBuffer = '';
			this._streamGotContent = false;
			this._streamSegmentText = ''; // Text for the current segment only.
			var self = this;
			var data = window.pressarkData;
			var requestPostId = data.postId || 0;
			if (/^\[(?:Continue|Confirmed)\]/i.test(message)) {
				requestPostId = self.resolveContinuationPostId(message, requestPostId);
			}

			// Capture message string before fetch().then() to avoid minifier
			// variable-shadowing bugs (the .then(function(response){}) parameter
			// can shadow outer closure variables after minification).
			var messageText = message;

			fetch(data.restUrl + 'chat-stream', {
				method: 'POST',
				signal: controller.signal,
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': data.nonce,
				},
				body: JSON.stringify({
					message: message,
					conversation: self.conversation.slice(-25),
					chat_id: self.currentChatId || 0,
					screen: data.screenId,
					post_id: requestPostId,
					deep_mode: self.deepModeActive,
					loaded_groups: self.loadedGroups,
					checkpoint: self.checkpoint,
				}),
			}).then(function (response) {
				if (!response.ok || !response.body) {
					// Fall back to non-streaming.
					self.finishRequest();
					self.conversation.pop(); // Remove the user message we added.
					if (bubble && bubble.parentNode) bubble.parentNode.removeChild(bubble);
					// Disable streaming for this session and retry.
					// Pass the original message text so the fallback can resend it
					// (inputEl was already cleared by sendMessageStream).
					window.pressarkData.streamingEnabled = false;
					self.sendMessage(messageText);
					return;
				}

				var reader = response.body.getReader();
				if (self._activeRequest) self._activeRequest.reader = reader;
				var decoder = new TextDecoder();
				var sseBuffer = '';

				function ensureBubble() {
					if (!bubble) {
						self.removeTypingIndicator();
						bubble = self.createStreamingBubble();
						self._streamGotContent = true;
					}
					return bubble;
				}

				function pump() {
					return reader.read().then(function (result) {
						if (result.done) {
							// Stream ended — finalize.
							ensureBubble();
							self.finalizeStream(bubble, textBuffer);
							return;
						}

						sseBuffer += decoder.decode(result.value, { stream: true });

						// Parse SSE events from buffer.
						var parsed = self.parseSSEBuffer(sseBuffer);
						sseBuffer = parsed.remaining;

						for (var i = 0; i < parsed.events.length; i++) {
							var evt = parsed.events[i];
							// Create the bubble on first meaningful content.
							if (evt.type === 'token' || evt.type === 'plan' || evt.type === 'step' || evt.type === 'tool_call' || evt.type === 'tool_progress' || evt.type === 'tool_result' || evt.type === 'done' || evt.type === 'error') {
								ensureBubble();
							}
							self.handleStreamEvent(evt, bubble, textBuffer);
							if (evt.type === 'token' && evt.data && evt.data.text) {
								textBuffer += evt.data.text;
							}
						}

						return pump();
					});
				}

				return pump();
			}).catch(function (err) {
				self.finishRequest();

				if (err && err.name === 'AbortError') {
					// User-initiated stop — handle partial content gracefully.
					if (bubble) {
						bubble.classList.remove('pressark-message-streaming');
						self._streamText = '';
						self._streamSegmentText = '';
						var contentEl = self.cleanupStreamingBubbleContent(bubble);
						var hasRenderableContent = !!(
							contentEl &&
							(
								(contentEl.textContent && contentEl.textContent.trim()) ||
								contentEl.children.length > 0
							)
						);
						if (hasRenderableContent && textBuffer) {
							self.conversation.push({ role: 'assistant', content: textBuffer });
							self.autoSaveChat();
						} else if (!hasRenderableContent) {
							// No content — remove empty bubble.
							if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
						}
					}
					return;
				}

				console.error('PressArk stream failed', err);
				if (bubble) {
					self.renderInterruptedStream(
						bubble,
						__( 'Couldn\'t reach PressArk. Check your connection and try again.', 'pressark' )
					);
				} else {
					self.appendRetryableError(__( 'Couldn\'t reach PressArk. Check your connection and try again.', 'pressark' ));
				}
			});
		},

		createStreamingBubble: function () {
			this.maybeAddTimestamp();

			var msgEl = document.createElement('div');
			msgEl.className = 'pressark-message pressark-message-assistant pressark-message-streaming';
			msgEl.dataset.timestamp = String(Date.now());

			var images = (window.pressarkData && window.pressarkData.images) || {};
			var logoSrc = this.findImage(images, ['WHITE-APP-LOGO', 'icon', 'app-icon']);
			msgEl.innerHTML =
				'<div class="pressark-ai-label">' +
				(logoSrc ? '<img src="' + logoSrc + '" alt="PressArk">' : '') +
				'<span>PressArk</span>' +
				'</div>' +
				'<div class="pressark-message-content"></div>';

			this.messagesEl.appendChild(msgEl);
			this.scrollToBottom();
			return msgEl;
		},

		parseSSEBuffer: function (buffer) {
			var events = [];
			var parts = buffer.split('\n\n');
			var remaining = parts.pop(); // Incomplete event stays in buffer.

			for (var i = 0; i < parts.length; i++) {
				var block = parts[i].trim();
				if (!block) continue;

				var eventType = '';
				var dataLines = [];
				var lines = block.split('\n');

				for (var j = 0; j < lines.length; j++) {
					var line = lines[j];
					if (line.indexOf('event: ') === 0) {
						eventType = line.substring(7).trim();
					} else if (line.indexOf('data: ') === 0) {
						dataLines.push(line.substring(6));
					} else if (line.indexOf(':') === 0) {
						// Comment line (keep-alive), ignore.
					}
				}

				if (dataLines.length > 0) {
					var rawData = dataLines.join('\n');
					var parsedData;
					try {
						parsedData = JSON.parse(rawData);
					} catch (e) {
						parsedData = { text: rawData };
					}
					events.push({ type: eventType || 'message', data: parsedData });
				}
			}

			return { events: events, remaining: remaining };
		},

		getToolProgressKey: function (data) {
			if (!data || typeof data !== 'object') return '';
			return String(data.tool_key || data.id || data.tool_use_id || data.tool || data.name || '');
		},

		_acceptToolProgressEvent: function (toolKey, sequence) {
			if (!toolKey) return true;
			if (!this._toolProgressState) this._toolProgressState = {};

			var nextSeq = parseInt(sequence || 0, 10);
			var current = this._toolProgressState[toolKey] || {};
			var lastSeq = parseInt(current.sequence || 0, 10);

			if (nextSeq > 0 && lastSeq > 0 && nextSeq <= lastSeq) {
				return false;
			}

			this._toolProgressState[toolKey] = {
				sequence: nextSeq > 0 ? nextSeq : (lastSeq + 1)
			};
			return true;
		},

		_findInlineStepRow: function (contentEl, toolKey, tool, matcher) {
			if (!contentEl) return null;
			var rows = contentEl.querySelectorAll('.pressark-inline-step');
			for (var i = rows.length - 1; i >= 0; i--) {
				var row = rows[i];
				if (toolKey && row.dataset.toolKey === toolKey) {
					if (typeof matcher === 'function' && !matcher(row)) {
						continue;
					}
					return row;
				}
				if (!toolKey && tool && row.dataset.tool === tool) {
					if (typeof matcher === 'function' && !matcher(row)) {
						continue;
					}
					return row;
				}
			}
			return null;
		},

		_getInlineStepIconMarkup: function (status) {
			if (status === 'reading') {
				return '<span class="pressark-step-icon pressark-step-icon--reading">' + pwIcons.loader + '</span>';
			}
			if (status === 'done') {
				return '<span class="pressark-step-icon pressark-step-icon--done">' + pwIcons.check + '</span>';
			}
			if (status === 'preparing_preview') {
				return '<span class="pressark-step-icon pressark-step-icon--preview">' + pwIcons.sparkles + '</span>';
			}
			if (status === 'needs_confirm') {
				return '<span class="pressark-step-icon pressark-step-icon--confirm">' + pwIcons.pencil + '</span>';
			}
			return '<span class="pressark-step-icon">\u2022</span>';
		},

		_applyInlineStepState: function (row, status, label, stepData) {
			if (!row) return;
			row.className = 'pressark-inline-step pressark-step--' + status;
			row.dataset.status = status;
			row.dataset.tool = stepData.tool || '';
			row.dataset.toolKey = stepData.toolKey || stepData.tool || '';

			if (!row.querySelector('.pressark-inline-step-body')) {
				row.innerHTML =
					this._getInlineStepIconMarkup(status) +
					'<span class="pressark-inline-step-body">' +
					'<span class="pressark-step-label"></span>' +
					'<span class="pressark-inline-step-detail" hidden></span>' +
					'<span class="pressark-inline-step-progress" hidden>' +
					'<span class="pressark-inline-step-progress-track"><span class="pressark-inline-step-progress-fill"></span></span>' +
					'<span class="pressark-inline-step-progress-text"></span>' +
					'</span>' +
					'</span>';
			}

			var currentIcon = row.querySelector('.pressark-step-icon');
			if (currentIcon) {
				currentIcon.outerHTML = this._getInlineStepIconMarkup(status);
			}

			var labelEl = row.querySelector('.pressark-step-label');
			if (labelEl) {
				labelEl.textContent = label;
			}

			var detailEl = row.querySelector('.pressark-inline-step-detail');
			if (detailEl) {
				if (stepData.detail) {
					detailEl.hidden = false;
					detailEl.textContent = stepData.detail;
				} else {
					detailEl.hidden = true;
					detailEl.textContent = '';
				}
			}

			var progressWrap = row.querySelector('.pressark-inline-step-progress');
			var progressFill = row.querySelector('.pressark-inline-step-progress-fill');
			var progressText = row.querySelector('.pressark-inline-step-progress-text');
			var percent = typeof stepData.progressPercent === 'number'
				? Math.max(0, Math.min(100, stepData.progressPercent))
				: null;

			if (progressWrap && progressFill && progressText) {
				if (percent !== null || status === 'done') {
					var resolvedPercent = percent !== null ? percent : 100;
					progressWrap.hidden = false;
					progressFill.style.width = resolvedPercent + '%';
					if (stepData.progressText) {
						progressText.textContent = stepData.progressText;
					} else if (stepData.progressValue !== null && typeof stepData.progressValue !== 'undefined' && stepData.progressMax !== null && typeof stepData.progressMax !== 'undefined') {
						progressText.textContent = stepData.progressValue + '/' + stepData.progressMax;
					} else {
						progressText.textContent = resolvedPercent + '%';
					}
				} else {
					progressWrap.hidden = true;
					progressFill.style.width = '0%';
					progressText.textContent = '';
				}
			}
		},

		handleStreamEvent: function (event, bubble) {
			// run_started arrives before the first token/step, so it must be
			// handled even when no streaming bubble exists yet.
			switch (event.type) {
				case 'run_started':
					if (event.data) {
						if (event.data.run_id) {
							this._activeRunId = event.data.run_id;
						}
						if (event.data.chat_id && !this.currentChatId) {
							this.currentChatId = event.data.chat_id;
						}
					}
					return;

				case 'status':
					// Connected — no action needed.
					return;
			}

			if (!bubble) return;
			var contentEl = bubble.querySelector('.pressark-message-content');

			switch (event.type) {
				case 'token':
					if (event.data && event.data.text) {
						this._streamText = (this._streamText || '') + event.data.text;
						this._streamSegmentText = (this._streamSegmentText || '') + event.data.text;
						// Get or create the current text segment (after the last step).
						var textSeg = this._getOrCreateTextSegment(contentEl);
						textSeg.innerHTML = this.renderFormattedMessage(this._streamSegmentText);
						this.scrollToBottom();
					}
					break;

				case 'plan':
					this._renderPlanCard(contentEl, event.data);
					this.syncPlanTrackerFromPlan(event.data);
					this._streamSegmentText = '';
					break;

				case 'step':
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, event.data);
					this.advancePlanTrackerFromStep(event.data);
					this._streamSegmentText = ''; // Next tokens go in a new segment.
					break;

				case 'tool_call':
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'reading',
						label: event.data.name ? event.data.name.replace(/_/g, ' ') : __( 'Processing', 'pressark' ),
						tool: event.data.name || '',
						toolKey: this.getToolProgressKey(event.data),
					});
					this.advancePlanTrackerFromStep({
						status: 'reading',
						label: event.data.name ? event.data.name.replace(/_/g, ' ') : __( 'Processing', 'pressark' )
					});
					this._streamSegmentText = '';
					break;

				case 'tool_progress':
					var progressData = (event.data && typeof event.data.progress === 'object' && event.data.progress)
						? event.data.progress
						: {};
					var progressKey = this.getToolProgressKey(event.data);
					if (!this._acceptToolProgressEvent(progressKey, event.data && event.data.sequence)) {
						break;
					}

					var processed = parseInt(progressData.processed, 10);
					var total = parseInt(progressData.total, 10);
					var percent = (!isNaN(processed) && !isNaN(total) && total > 0)
						? Math.round((processed / total) * 100)
						: null;
					var toolName = (event.data && (event.data.name || event.data.tool)) || __( 'Processing', 'pressark' );
					var progressLabel = toolName.replace(/_/g, ' ');
					if (!isNaN(processed) && !isNaN(total) && total > 0) {
						progressLabel += ' ' + processed + '/' + total;
					}

					var progressDetail = '';
					if (typeof progressData.message === 'string' && progressData.message) {
						progressDetail = progressData.message;
					} else {
						var detailParts = [];
						if (!isNaN(progressData.updated)) {
							/* translators: %d: number of updated items. */
							detailParts.push(sprintf( __( '%d updated', 'pressark' ), progressData.updated ));
						}
						if (!isNaN(progressData.errors) && progressData.errors > 0) {
							/* translators: %d: number of errors. */
							detailParts.push(sprintf( _n( '%d error', '%d errors', progressData.errors, 'pressark' ), progressData.errors ));
						}
						progressDetail = detailParts.join(' · ');
					}

					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'reading',
						label: progressLabel,
						tool: event.data.name || event.data.tool || '',
						toolKey: progressKey,
						detail: progressDetail,
						progressPercent: percent,
						progressValue: !isNaN(processed) ? processed : null,
						progressMax: !isNaN(total) ? total : null,
						progressText: (!isNaN(processed) && !isNaN(total) && total > 0) ? (processed + '/' + total) : ''
					});
					this.advancePlanTrackerFromStep({
						status: 'reading',
						label: progressLabel
					});
					this._streamSegmentText = '';
					break;

				case 'tool_result':
					var doneKey = this.getToolProgressKey(event.data);
					var doneName = (event.data.name || '').replace(/_/g, ' ');
					if (doneKey && this._toolProgressState) {
						delete this._toolProgressState[doneKey];
					}
					this._markPriorTextSegmentsAsStatus(contentEl);
					this._renderInlineStep(contentEl, {
						status: 'done',
						/* translators: %s: completed tool or action name. */
						label: doneName ? sprintf( __( '%s complete', 'pressark' ), doneName ) : __( 'Action complete', 'pressark' ),
						tool: event.data.name || '',
						toolKey: doneKey,
						detail: event.data.summary || '',
						progressPercent: 100,
					});
					this.advancePlanTrackerFromStep({
						status: 'done',
						label: doneName || __( 'Action complete', 'pressark' )
					});
					this._streamSegmentText = '';
					break;

				case 'done':
					this.finalizeStreamResponse(event.data, bubble);
					break;

				case 'error':
					this.finishRequest();
					var msg = (event.data && event.data.message) || __( 'An error occurred.', 'pressark' );
					this.renderInterruptedStream(bubble, msg);
					break;
			}
		},

		/**
		 * Get or create a text segment element within the content area.
		 * Text segments are separated by inline step rows.
		 * When text arrives after a step, we need a new segment so
		 * re-rendering the formatted markdown doesn't clobber the step rows.
		 */
		_getOrCreateTextSegment: function (contentEl) {
			// If there are no inline steps or plan cards yet, the contentEl itself is the segment.
			var steps = contentEl.querySelectorAll('.pressark-inline-step');
			var planCards = contentEl.querySelectorAll('.pressark-plan-card');
			if (!steps.length && !planCards.length) return contentEl;

			// Find the last child. If it's a text segment div, reuse it.
			var last = contentEl.lastElementChild;
			if (last && last.classList.contains('pressark-stream-text-segment')) {
				return last;
			}

			// The last child is a step row — we need a new text segment after it.
			var seg = document.createElement('div');
			seg.className = 'pressark-stream-text-segment';
			contentEl.appendChild(seg);
			return seg;
		},

		/**
		 * When a tool call / step / tool_result arrives, any text segments that
		 * came before it are retroactively intermediate status, not final reply
		 * text. Add the --status modifier so CSS can dim them. Safe to call
		 * multiple times (idempotent via classList.add).
		 */
		_markPriorTextSegmentsAsStatus: function (contentEl) {
			if (!contentEl) return;
			var segs = contentEl.querySelectorAll(':scope > .pressark-stream-text-segment');
			for (var i = 0; i < segs.length; i++) {
				var seg = segs[i];
				// Empty segments carry no information — do not visually flag them.
				if (!seg.textContent || !seg.textContent.trim()) continue;
				seg.classList.add('pressark-stream-text-segment--status');
			}
		},

		/**
		 * Render a collapsible execution plan card inline within the bubble.
		 * @since 5.2.0
		 */
		_renderPlanCard: function (contentEl, planItems) {
			if (!contentEl) return null;
			contentEl.classList.add('pressark-message-content--planning');
			return this.renderPlanReadyCard(planItems, contentEl);
		},

		/**
		 * Update plan card step statuses as execution progresses.
		 * @since 5.2.0
		 */
		_updatePlanStep: function (bubble, stepIndex, status) {
			if (!bubble) return;
			var items = bubble.querySelectorAll('.pressark-plan-steps li');
			if (stepIndex < items.length) {
				items[stepIndex].className = 'step-' + status;
			}
		},

		/**
		 * Render a tool/step row inline within the bubble's content area,
		 * interleaved with text in the order events arrive.
		 */
		_renderInlineStep: function (contentEl, stepData) {
			if (!contentEl) return;
			contentEl.classList.add('pressark-message-content--activity');

			var rawStatus = stepData.status || 'done';
			var status = this.normalizeStepStatus(rawStatus);
			var label = stepData.label || stepData.tool || '';
			var tool = stepData.tool || '';
			var toolKey = stepData.toolKey || tool;
			var existingRow = this._findInlineStepRow(
				contentEl,
				toolKey,
				tool,
				status === 'done'
					? function (row) { return row.dataset.status === 'done'; }
					: function (row) { return row.dataset.status !== 'done'; }
			);
			if (existingRow) {
				this._applyInlineStepState(existingRow, status, label, stepData);
				this.scrollToBottom();
				return;
			}

			// Before inserting a step, if there's accumulated text directly in
			// contentEl (no segments yet), wrap it in a segment so it stays above the step.
			var steps = contentEl.querySelectorAll('.pressark-inline-step');
			if (!steps.length && this._streamText) {
				var textWrap = document.createElement('div');
				textWrap.className = 'pressark-stream-text-segment';
				// Move all current children into the wrapper.
				while (contentEl.firstChild) {
					textWrap.appendChild(contentEl.firstChild);
				}
				contentEl.appendChild(textWrap);
			}

			// Build the step row.
			var row = document.createElement('div');
			row.className = 'pressark-inline-step pressark-step--' + status;
			row.dataset.tool = tool;
			row.dataset.toolKey = toolKey;
			row.dataset.status = status;
			contentEl.appendChild(row);
			this._applyInlineStepState(row, status, label, stepData);
			this.scrollToBottom();
		},

		_normalizeStreamReplyText: function (text) {
			return String(text || '').replace(/\s+/g, ' ').trim();
		},

		_streamReplyMatchesFinal: function (streamedText, replyText) {
			return this._normalizeStreamReplyText(streamedText) === this._normalizeStreamReplyText(replyText);
		},

		_appendStreamFinalResult: function (contentEl, replyText) {
			if (!contentEl || !replyText) return;
			var existing = contentEl.querySelector('.pressark-stream-final-result');
			if (existing && existing.parentNode) {
				existing.parentNode.removeChild(existing);
			}

			var summary = document.createElement('div');
			summary.className = 'pressark-stream-final-result';
			summary.innerHTML =
				'<div class="pressark-stream-final-result__label">' + this.escapeHtml(__( 'Final result', 'pressark' )) + '</div>' +
				'<div class="pressark-stream-final-result__body">' + this.renderFormattedMessage(replyText) + '</div>';
			contentEl.appendChild(summary);
		},

		finalizeStreamResponse: function (result, bubble) {
			var streamedReplyText = this._streamText || '';
			this.finishRequest();
			this._streamText = '';
			this._streamSegmentText = '';

			// Remove streaming class.
			bubble.classList.remove('pressark-message-streaming');
			var silentContinuation = this.isSilentContinuationResult(result);

			if (this.shouldAutoContinueCompactedRun(result)) {
				if (this.getResultActivityItems(result).length > 0) {
					this.renderActivityStripBefore(this.getResultActivityItems(result), bubble);
				} else if (silentContinuation) {
					this.renderSilentContinuationStep(result, bubble);
				}
				if (bubble.parentNode) {
					bubble.parentNode.removeChild(bubble);
				}
				this.continueCompactedRun(result);
				return;
			}

			var responseType = result.type || 'final_response';
			var replyText = result.reply || result.message || '';
			if (responseType === 'permission_required' && result.upgrade_prompt) {
				var streamUpgradeUrl = (result.upgrade_url || window.pressarkData.upgradeUrl || '#');
				replyText += (replyText ? '\n\n' : '') + '[' + __( 'Manage billing', 'pressark' ) + '](' + streamUpgradeUrl + ')';
			}
			var contentEl = bubble.querySelector('.pressark-message-content');
			var activityItems = this.getResultActivityItems(result);

			// Rebuild the bubble content: final activity strip, then formatted text.
			if (silentContinuation) {
				if (activityItems.length > 0) {
					this.renderActivityStripBefore(activityItems, bubble);
				} else {
					this.renderSilentContinuationStep(result, bubble);
				}
				if (bubble.parentNode) {
					bubble.parentNode.removeChild(bubble);
				}
			} else if (replyText && contentEl) {
				// Collect inline steps that were streamed, to rebuild as a proper strip.
				var inlineSteps = contentEl.querySelectorAll('.pressark-inline-step');
				var hadInlineSteps = inlineSteps.length > 0;

				// Detach plan cards before clearing — they survive the finalize.
				var hadPlanCards = contentEl.querySelectorAll('.pressark-plan-card').length > 0;
				var hadStreamedContent = !!this._normalizeStreamReplyText(streamedReplyText) || hadInlineSteps || hadPlanCards;

				if (!hadStreamedContent || !this._normalizeStreamReplyText(contentEl.textContent)) {
					contentEl.innerHTML = this.renderFormattedMessage(replyText);
				} else if (!this._streamReplyMatchesFinal(streamedReplyText, replyText)) {
					this._appendStreamFinalResult(contentEl, replyText);
				}

				// If there were inline steps, render the final activity strip above the bubble.
				if (activityItems.length > 0 && !hadInlineSteps) {
					this.renderActivityStripBefore(activityItems, bubble);
					// No final steps from server — remove inline steps (they're already cleared).
				}

				this.decorateAssistantMessage(bubble, result);
				this.conversation.push({ role: 'assistant', content: replyText });
			} else if (activityItems.length > 0) {
				// No reply text but has steps.
				this.renderActivityStripBefore(activityItems, bubble);
				this.decorateAssistantMessage(bubble, result);
			}

			// Branch on response type.
			if (responseType === 'permission_required') {
				// No extra UI yet; the assistant message above carries the prompt/link.
			} else if (responseType === 'queued') {
				this.pendingTaskCount = Math.max(this.pendingTaskCount, 1);
				this.syncTaskPolling(true);
			} else if (responseType === 'preview') {
				this.openPreview({
					preview_session_id: result.preview_session_id,
					preview_url: result.preview_url,
					diff: result.diff,
					risk_receipt: result.risk_receipt,
				});
			} else if (responseType === 'confirm_card') {
				if (result.pending_actions && result.pending_actions.length > 0) {
					for (var p = 0; p < result.pending_actions.length; p++) {
						this.renderPreviewCard(result.pending_actions[p], result.run_id || '', p);
					}
				}
			} else if (responseType === 'plan_ready') {
				if (contentEl) {
					this._renderPlanCard(contentEl, result);
				}
			} else {
				// final_response
				if (result.pending_actions && result.pending_actions.length > 0) {
					for (var p2 = 0; p2 < result.pending_actions.length; p2++) {
						this.renderPreviewCard(result.pending_actions[p2], result.run_id || '', p2);
					}
				}

				// v5.8.2 (2026-05-13, iter-38): server signals that any earlier
				// Plan Mode card in this chat is obsolete.
				if (result.plan_card_obsolete === true) {
					this.removeObsoletePlanCards(result.run_id || '', contentEl);
				}
			}

			this.applyResultState(result);

			if (result.suggestions) {
				this.renderSuggestionChips(result.suggestions);
			}

			this.autoSaveChat();
		},

		finalizeStream: function (bubble, textBuffer) {
			// Called when the ReadableStream ends without a 'done' event.
			// This can happen if the connection drops.
			if (this.isSending) {
				this.finishRequest();
				this.renderInterruptedStream(
					bubble,
					__( 'PressArk lost the stream before this response finished. The reply above may be incomplete. Please retry.', 'pressark' )
				);
			}
		},

		// ── Notification Dot for Background Tasks ───────────────────

		updateActivityUi: function () {
			var count = this.unreadTaskCount || 0;
			var toggle = this.toggleBtn;
			var dot = toggle ? toggle.querySelector('.pressark-notif-dot') : null;

			if (this.activityBtn) {
				var title = '';
				if (count > 0) {
					/* translators: %d: number of unread activity items. */
					title = sprintf( _n( 'Open Activity inbox (%d unread)', 'Open Activity inbox (%d unread)', count, 'pressark' ), count );
				} else {
					title = __( 'Open Activity inbox', 'pressark' );
				}
				this.activityBtn.setAttribute('title', title);
				this.activityBtn.setAttribute('aria-label', title);
			}

			if (this.activityCountEl) {
				this.activityCountEl.hidden = count < 1;
				this.activityCountEl.textContent = count > 99 ? '99+' : String(count);
			}

			if (!toggle) {
				return;
			}

			if (count < 1) {
				toggle.classList.remove('has-notifications');
				if (dot) {
					dot.remove();
				}
				return;
			}

			if (!dot) {
				dot = document.createElement('span');
				dot.className = 'pressark-notif-dot';
				toggle.appendChild(dot);
			}

			dot.textContent = count > 99 ? '99+' : String(count);
			toggle.classList.add('has-notifications');
		},

		// ── Customizer Handoff ───────────────────────────────────────

		isCustomizerEligible: function (diff) {
			var customizerFields = ['blogname', 'blogdescription', 'header_image',
				'background_color', 'site_icon'];
			if (!diff || !diff.length) return false;
			for (var i = 0; i < diff.length; i++) {
				var entry = diff[i];
				if (entry.items) {
					for (var j = 0; j < entry.items.length; j++) {
						if (customizerFields.indexOf(entry.items[j].field) !== -1) return true;
					}
				}
				if (entry.field && customizerFields.indexOf(entry.field) !== -1) return true;
			}
			return false;
		},
	};

	// Background task polling is owned by PressArk itself.
	// The poll loop only runs while the panel is open or async work is pending.

	// Initialize when DOM is ready.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () {
			PressArk.init();
		});
	} else {
		PressArk.init();
	}

	window.PressArk = PressArk;
})();
